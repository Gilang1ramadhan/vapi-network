import { readFileSync } from "node:fs";

import { describe, expect, it } from "vitest";
import { z } from "zod";

import {
  MARKETPLACE_DISCOVERY_PROTOCOL,
  MARKETPLACE_KINDS,
  MARKETPLACE_RANKING_VERSION,
  SOLANA_DEVNET_CAIP2,
  SOLANA_MAINNET_CAIP2,
  X402_SOLANA_MAINNET_CAIP2,
  apiMarketplaceHitSchema,
  isMirroredHit,
  LISTING_HEALTH_STATES,
  listingHealthSchema,
  listingHealthStateSchema,
  marketplaceAlternativeSchema,
  marketplaceDiscoveryInputSchema,
  marketplaceDiscoveryPageSchema,
  marketplaceHitSchema,
} from "./index.js";

const fixture = JSON.parse(
  readFileSync(
    new URL("../test/fixtures/marketplace-discovery-page.json", import.meta.url),
    "utf8",
  ),
) as unknown;

describe("marketplace discovery wire contract", () => {
  const apiHits = (fixture as { items: Record<string, unknown>[] }).items.slice(0, 2);
  const health = {
    state: "healthy",
    uptime7d: 0.9941,
    latencyP50Ms: 212.4,
    latencyP95Ms: 480,
    checks7d: 168,
  };

  it("exports and parses the registry's health states and summary", () => {
    expect(LISTING_HEALTH_STATES).toEqual(["healthy", "degraded", "outage", "unknown"]);
    for (const state of LISTING_HEALTH_STATES) {
      expect(listingHealthStateSchema.parse(state)).toBe(state);
      expect(listingHealthSchema.parse({ ...health, state })).toEqual({ ...health, state });
    }
    expect(listingHealthStateSchema.parse("recovering")).toBe("unknown");
    expect(listingHealthSchema.parse({ ...health, state: "recovering" }).state).toBe("unknown");
    expect(
      listingHealthSchema.parse({
        state: "recovering",
        uptime7d: 99,
        latencyP50Ms: -1,
        latencyP95Ms: "slow",
        checks7d: 1.5,
      }),
    ).toEqual({
      state: "unknown",
      uptime7d: null,
      latencyP50Ms: null,
      latencyP95Ms: null,
      checks7d: 0,
    });
    expect(listingHealthSchema.parse({})).toEqual({
      state: "unknown",
      uptime7d: null,
      latencyP50Ms: null,
      latencyP95Ms: null,
      checks7d: 0,
    });
  });

  it.each(apiHits)("tolerates absent and malformed health on $provenance APIs", (hit) => {
    expect(apiMarketplaceHitSchema.parse({ ...hit, health }).health).toEqual(health);
    for (const malformed of [undefined, null, "outage", 42, []]) {
      expect(apiMarketplaceHitSchema.parse({ ...hit, health: malformed }).health).toBeUndefined();
    }
    const older = apiMarketplaceHitSchema.parse(hit);
    expect(older.health).toBeUndefined();
    expect(older.alternatives).toBeUndefined();
  });

  it.each(apiHits)("filters, deduplicates and caps alternatives on $provenance APIs", (hit) => {
    const cheaper = { ref: "cheaper-api", reason: "cheaper" };
    const healthier = { ref: "healthier-api", reason: "healthier" };
    expect(marketplaceAlternativeSchema.parse(cheaper)).toEqual(cheaper);
    expect(
      apiMarketplaceHitSchema.parse({
        ...hit,
        alternatives: [
          null,
          { ref: "", reason: "cheaper" },
          { ref: "future", reason: "faster" },
          cheaper,
          { ref: "cheaper-api", reason: "healthier" },
          healthier,
          { ref: "third-api", reason: "cheaper" },
        ],
      }).alternatives,
    ).toEqual([cheaper, healthier]);
    for (const malformed of [undefined, null, "no alternatives", [], [{ ref: "missing-reason" }]]) {
      expect(
        apiMarketplaceHitSchema.parse({ ...hit, alternatives: malformed }).alternatives,
      ).toBeUndefined();
    }
  });

  it("keeps failed_calls_free and drops unknown badge codes", () => {
    const hit = apiHits[0]!;
    const badge = { code: "failed_calls_free", label: "Provider failures aren't charged" };
    expect(
      apiMarketplaceHitSchema.parse({
        ...hit,
        card: {
          ...(hit.card as Record<string, unknown>),
          badges: [badge, { code: "future_badge", label: "Future" }],
        },
      }).card.badges,
    ).toEqual([badge]);
  });

  it.each([MARKETPLACE_RANKING_VERSION, "marketplace-ranking-v2", "marketplace-ranking-v9"])(
    "accepts the shared cross-runtime fixture with %s",
    (rankingVersion) => {
      const page = marketplaceDiscoveryPageSchema.parse({
        ...(fixture as Record<string, unknown>),
        rankingVersion,
      });

      expect(page.protocol).toBe(MARKETPLACE_DISCOVERY_PROTOCOL);
      expect(page.rankingVersion).toBe(rankingVersion);
      expect(page.items.map((item) => item.kind)).toEqual([
        "api",
        "api",
        "service_offer",
        "open_request",
      ]);
      expect(
        page.items.slice(0, 2).map((item) => ("provenance" in item ? item.provenance : null)),
      ).toEqual(["self_listed", "indexed"]);
      expect(
        page.items.slice(0, 2).map((item) => (item.kind === "api" ? item.execution.mode : null)),
      ).toEqual(["direct", "direct"]);
    },
  );

  it("exports a JSON Schema for MCP result registration", () => {
    expect(() => z.toJSONSchema(marketplaceDiscoveryPageSchema)).not.toThrow();
  });

  it("never promotes a Work kind to an API hit, whatever extra axes ride along", () => {
    const [, , service, request] = marketplaceDiscoveryPageSchema.parse(fixture).items;

    for (const extra of [
      { provenance: "self_listed" },
      { provenance: "indexed" },
      { execution: { mode: "direct" } },
      { source: "vapi" },
    ]) {
      // Additive keys are tolerated so a newer registry cannot break a client,
      // but they never make a Work listing payable: only `kind` decides that.
      expect(marketplaceHitSchema.parse({ ...service, ...extra }).kind).toBe("service_offer");
      expect(marketplaceHitSchema.parse({ ...request, ...extra }).kind).toBe("open_request");
      expect(() => apiMarketplaceHitSchema.parse({ ...service, ...extra })).toThrow();
      expect(() => apiMarketplaceHitSchema.parse({ ...request, ...extra })).toThrow();
    }
  });

  it("carries the registry's group and fee disclosures on every kind of hit", () => {
    const page = marketplaceDiscoveryPageSchema.parse({
      ...(fixture as { items: unknown[] }),
      items: (fixture as { items: Record<string, unknown>[] }).items.map((item, index) => ({
        ...item,
        group: ["vapi", "external", "partner", "added"][index],
        fee:
          index === 0
            ? { bps: 500, label: "Network fee kept by this API's legacy payout splitter" }
            : { bps: 0, label: "No network fee" },
      })),
    });

    expect(page.items.map((item) => item.group)).toEqual(["vapi", "external", "partner", "added"]);
    expect(page.items[0]?.fee).toEqual({
      bps: 500,
      label: "Network fee kept by this API's legacy payout splitter",
    });
    expect(page.items.map((item) => item.fee?.bps)).toEqual([500, 0, 0, 0]);
    // Unknown or malformed presentation disclosures are omitted safely.
    expect(
      marketplaceHitSchema.parse({ ...page.items[0], group: "affiliate" }).group,
    ).toBeUndefined();
    expect(
      marketplaceHitSchema.parse({ ...page.items[0], fee: { bps: -1, label: "negative" } }).fee,
    ).toBeUndefined();
    expect(marketplaceHitSchema.parse({ ...page.items[0], fee: { bps: 500 } }).fee).toBeUndefined();
  });

  it("carries the verification tier on every kind of hit, defaulting to none", () => {
    const page = fixture as { items: Record<string, unknown>[] };

    // The shared fixture predates the tier, so every hit reads as `none`.
    expect(
      marketplaceDiscoveryPageSchema.parse(fixture).items.map((item) => item.verification),
    ).toEqual(["none", "none", "none", "none"]);

    const tiered = marketplaceDiscoveryPageSchema.parse({
      ...page,
      items: page.items.map((item, index) => ({
        ...item,
        verification: ["verified", "none", "requested", "verified"][index],
      })),
    });
    expect(tiered.items.map((item) => item.verification)).toEqual([
      "verified",
      "none",
      "requested",
      "verified",
    ]);

    // A tier this client does not know must never read as a vAPI endorsement.
    for (const unknown of ["platinum", null, 7, ""]) {
      expect(
        marketplaceHitSchema.parse({ ...page.items[0], verification: unknown }).verification,
      ).toBe("none");
    }
  });

  it("carries ERC-8004 identity on hits and service records, tolerating malformed fields", () => {
    const page = fixture as { items: Record<string, unknown>[] };
    const identity = { erc8004Id: "42", reputation: { score: 4.567, count: 1 } };
    const parsed = marketplaceDiscoveryPageSchema.parse({
      ...page,
      items: page.items.map((item, index) =>
        index === 0 || index === 2 ? { ...item, identity } : item,
      ),
    });

    expect(parsed.items[0]?.identity).toEqual(identity);
    expect(parsed.items[2]?.identity).toEqual(identity);

    for (const malformed of [42, { erc8004Id: "" }, null]) {
      const malformedPage = marketplaceDiscoveryPageSchema.parse({
        ...page,
        items: page.items.map((item, index) =>
          index === 0 || index === 2 ? { ...item, identity: malformed } : item,
        ),
      });
      expect(malformedPage.items[0]?.identity).toBeUndefined();
      expect(malformedPage.items[2]?.identity).toBeUndefined();
    }

    const malformedReputation = marketplaceDiscoveryPageSchema.parse({
      ...page,
      items: page.items.map((item, index) =>
        index === 0 || index === 2
          ? { ...item, identity: { erc8004Id: "42", reputation: { score: "4.5", count: -1 } } }
          : item,
      ),
    });
    expect(malformedReputation.items[0]?.identity).toEqual({ erc8004Id: "42" });
    expect(malformedReputation.items[2]?.identity).toEqual({ erc8004Id: "42" });
  });

  it("tolerates additive registry fields and passes them through untouched", () => {
    const page = fixture as { items: Record<string, unknown>[] };
    const parsed = marketplaceDiscoveryPageSchema.parse({
      ...page,
      experimentalRanking: "rrf-v2",
      items: page.items.map((item) => ({
        ...item,
        somethingTheRegistryAddedLater: { nested: true },
        card: { ...(item.card as Record<string, unknown>), highlight: "new" },
      })),
    });

    expect(parsed).toMatchObject({ experimentalRanking: "rrf-v2" });
    expect(parsed.items[0]).toMatchObject({
      somethingTheRegistryAddedLater: { nested: true },
      card: { highlight: "new" },
    });
  });

  it("keeps a row when badge and display-only disclosure vocabularies advance", () => {
    const page = fixture as { items: Record<string, unknown>[] };
    const parsed = marketplaceDiscoveryPageSchema.parse({
      ...page,
      items: page.items.map((item) => ({
        ...item,
        group: "future_group",
        fee: { bps: "unknown", label: "Future fee" },
        card: {
          ...(item.card as Record<string, unknown>),
          badges: [
            { code: "live_x402", label: "Live x402" },
            { code: "future_badge", label: "A newer registry badge" },
          ],
        },
      })),
    });

    expect(parsed.items).toHaveLength(page.items.length);
    expect(parsed.items[0]?.group).toBeUndefined();
    expect(parsed.items[0]?.fee).toBeUndefined();
    expect(parsed.items[0]?.card.badges).toEqual([{ code: "live_x402", label: "Live x402" }]);
  });

  it("binds every marketplace kind to its one valid action and provenance policy", () => {
    const [api, externalApi] = (() => {
      const items = marketplaceDiscoveryPageSchema.parse(fixture).items;
      return [items[0], items[1]] as const;
    })();

    expect(() =>
      marketplaceHitSchema.parse({
        ...api,
        action: { type: "start_engagement", href: "/work/listings/weather" },
      }),
    ).toThrow();
    expect(() =>
      marketplaceHitSchema.parse({
        ...api,
        action: { type: "invoke_api", href: "http://insecure.example/pay" },
      }),
    ).toThrow();
    // A mirrored listing must carry its own target; a first-party card never does.
    expect(() => marketplaceHitSchema.parse({ ...api, provenance: "indexed" })).toThrow();
    // The reverse now parses — an inline target is just an extra key on a
    // first-party card — but provenance, not the key, decides what is payable:
    // only a mirrored hit is ever called at its inline URL.
    const relabelled = marketplaceHitSchema.parse({
      ...externalApi,
      provenance: "self_listed",
    });
    expect(isMirroredHit(relabelled)).toBe(false);
    expect(() =>
      marketplaceHitSchema.parse({
        ...externalApi,
        execution: { mode: "direct" },
      }),
    ).toThrow();
  });

  it("allows a gateway execution mode only for first-party provenance", () => {
    const [api, externalApi] = marketplaceDiscoveryPageSchema.parse(fixture).items;

    expect(() =>
      marketplaceHitSchema.parse({ ...api, execution: { mode: "gateway" } }),
    ).not.toThrow();
    expect(() =>
      marketplaceHitSchema.parse({ ...api, provenance: "partner", execution: { mode: "gateway" } }),
    ).not.toThrow();
    // vAPI never fronts a listing it merely mirrored — ADR 0009.
    if (externalApi?.kind !== "api" || externalApi.provenance !== "indexed") {
      throw new Error("Expected the shared fixture to include a mirrored API hit");
    }
    expect(() =>
      marketplaceHitSchema.parse({
        ...externalApi,
        execution: { ...externalApi.execution, mode: "gateway" },
      }),
    ).toThrow();
  });

  it("rejects missing or malformed mirrored execution authority", () => {
    const external = marketplaceDiscoveryPageSchema.parse(fixture).items[1];
    if (external?.kind !== "api" || external.provenance !== "indexed") {
      throw new Error("Expected the shared fixture to include a mirrored API hit");
    }

    const withoutExecution: Partial<typeof external> = { ...external };
    Reflect.deleteProperty(withoutExecution, "execution");
    expect(() => marketplaceHitSchema.parse(withoutExecution)).toThrow();
    expect(() =>
      marketplaceHitSchema.parse({
        ...external,
        execution: { ...external.execution, method: null },
      }),
    ).not.toThrow();
    for (const execution of [
      {
        mode: "direct",
        url: "http://api.weather.example/pay",
        method: "GET",
        network: "eip155:8453",
      },
      {
        mode: "direct",
        url: "https://user:secret@api.weather.example/pay",
        method: "GET",
        network: "eip155:8453",
      },
      {
        mode: "direct",
        url: "https://api.weather.example/pay",
        method: "TRACE",
        network: "eip155:8453",
      },
      {
        mode: "direct",
        url: "https://api.weather.example/pay",
        method: null,
        network: "base",
      },
    ]) {
      expect(() => marketplaceHitSchema.parse({ ...external, execution })).toThrow();
    }
  });

  it("accepts Solana CAIP-2 networks and normalizes bare Solana aliases", () => {
    const external = marketplaceDiscoveryPageSchema.parse(fixture).items[1];
    if (external?.kind !== "api" || external.provenance !== "indexed") {
      throw new Error("Expected the shared fixture to include a mirrored API hit");
    }
    const withNetwork = (network: string) => ({
      ...external,
      execution: { ...external.execution, network },
    });

    expect(marketplaceHitSchema.parse(withNetwork(X402_SOLANA_MAINNET_CAIP2))).toMatchObject({
      execution: { network: X402_SOLANA_MAINNET_CAIP2 },
    });
    expect(marketplaceHitSchema.parse(withNetwork("solana"))).toMatchObject({
      execution: { network: X402_SOLANA_MAINNET_CAIP2 },
    });
    expect(marketplaceHitSchema.parse(withNetwork("solana-devnet"))).toMatchObject({
      execution: { network: SOLANA_DEVNET_CAIP2 },
    });
    expect(marketplaceHitSchema.parse(withNetwork(SOLANA_MAINNET_CAIP2))).toMatchObject({
      execution: { network: SOLANA_MAINNET_CAIP2 },
    });
    expect(() => marketplaceHitSchema.parse(withNetwork("garbage"))).toThrow();
  });

  it("keeps full-page parsing strict for malformed marketplace rows", () => {
    const page = fixture as { items: Record<string, unknown>[] };
    expect(() =>
      marketplaceDiscoveryPageSchema.parse({
        ...page,
        items: [...page.items, { unexpected: true }],
      }),
    ).toThrow();
  });

  it("normalizes bounded input and rejects ambiguous kind lists", () => {
    expect(
      marketplaceDiscoveryInputSchema.parse({
        q: "  weather  ",
        kinds: [...MARKETPLACE_KINDS],
        network: "  eip155:8453 ",
        limit: 24,
        includeUnverified: true,
        includeOutage: true,
      }),
    ).toEqual({
      q: "weather",
      kinds: ["api", "service_offer", "open_request"],
      network: "eip155:8453",
      limit: 24,
      includeUnverified: true,
      includeOutage: true,
    });
    expect(() => marketplaceDiscoveryInputSchema.parse({ kinds: ["api", "api"] })).toThrow();
    expect(() => marketplaceDiscoveryInputSchema.parse({ limit: 51 })).toThrow();
    expect(() => marketplaceDiscoveryInputSchema.parse({ q: "x".repeat(201) })).toThrow();
    // The request this client builds stays strict: a garbage trust switch is a
    // client bug and must fail here, not travel to the registry.
    expect(() => marketplaceDiscoveryInputSchema.parse({ includeUnverified: "yes" })).toThrow();
    expect(() => marketplaceDiscoveryInputSchema.parse({ includeOutage: "yes" })).toThrow();
    expect(marketplaceDiscoveryInputSchema.parse({})).toEqual({});
  });
});
