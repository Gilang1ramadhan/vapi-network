import { mkdir, mkdtemp, readFile, rm, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";

import { afterEach, describe, expect, it, vi } from "vitest";

import { __setAtomicFileTestHooks } from "./atomic-file.js";
import { getVapiPaths, migrateLegacyVapiHome } from "./config.js";
import { appendReceipt, readReceipts } from "./receipts.js";

const temporaryDirectories: string[] = [];

afterEach(async () => {
  __setAtomicFileTestHooks(undefined);
  vi.unstubAllEnvs();
  await Promise.all(
    temporaryDirectories.splice(0).map((path) => rm(path, { recursive: true, force: true })),
  );
});

describe("vAPI config home", () => {
  it("uses VAPI_HOME and includes the local receipt and search ledgers", () => {
    vi.stubEnv("VAPI_HOME", "/tmp/vapi-home");
    expect(getVapiPaths()).toEqual({
      directory: "/tmp/vapi-home",
      agentsDir: "/tmp/vapi-home/agents",
      config: "/tmp/vapi-home/config.json",
      keystore: "/tmp/vapi-home/keystore.json",
      receipts: "/tmp/vapi-home/receipts.jsonl",
      searches: "/tmp/vapi-home/searches.jsonl",
      ledger: "/tmp/vapi-home/spend-ledger.json",
      updateCheck: "/tmp/vapi-home/update-check.json",
    });
  });

  it("copies every missing stable legacy file without deleting or overwriting", async () => {
    const root = await mkdtemp(join(tmpdir(), "vapi-migrate-"));
    temporaryDirectories.push(root);
    const legacyDirectory = join(root, "legacy");
    const targetDirectory = join(root, "new");
    await mkdir(legacyDirectory);
    for (const filename of [
      "config.json",
      "keystore.json",
      "receipts.jsonl",
      "searches.jsonl",
      "spend-ledger.json",
    ]) {
      await writeFile(join(legacyDirectory, filename), `legacy ${filename}`);
    }
    await mkdir(targetDirectory);
    await writeFile(join(targetDirectory, "config.json"), "new config");
    const notice = vi.fn();

    const copied = await migrateLegacyVapiHome({ legacyDirectory, targetDirectory, notice });

    expect(copied).toEqual([
      join(targetDirectory, "keystore.json"),
      join(targetDirectory, "receipts.jsonl"),
      join(targetDirectory, "searches.jsonl"),
      join(targetDirectory, "spend-ledger.json"),
    ]);
    expect(await readFile(join(targetDirectory, "config.json"), "utf8")).toBe("new config");
    for (const filename of [
      "keystore.json",
      "receipts.jsonl",
      "searches.jsonl",
      "spend-ledger.json",
    ]) {
      expect(await readFile(join(legacyDirectory, filename), "utf8")).toBe(`legacy ${filename}`);
      expect(await readFile(join(targetDirectory, filename), "utf8")).toBe(`legacy ${filename}`);
    }
    expect(notice).toHaveBeenCalledOnce();
  });

  it("serializes a legacy receipt copy with receipt appends", async () => {
    const root = await mkdtemp(join(tmpdir(), "vapi-migrate-receipts-"));
    temporaryDirectories.push(root);
    const legacyDirectory = join(root, "legacy");
    const targetDirectory = join(root, "new");
    await mkdir(legacyDirectory);
    const legacyReceipt = {
      id: "legacy-receipt",
      timestamp: "2026-09-30T10:00:00.000Z",
      resourceUrl: "https://api.example/legacy",
    };
    await writeFile(join(legacyDirectory, "receipts.jsonl"), `${JSON.stringify(legacyReceipt)}\n`);

    const receiptsPath = join(targetDirectory, "receipts.jsonl");
    let migrationLocked!: () => void;
    const migrationLock = new Promise<void>((resolve) => {
      migrationLocked = resolve;
    });
    let releaseMigration!: () => void;
    const migrationGate = new Promise<void>((resolve) => {
      releaseMigration = resolve;
    });
    __setAtomicFileTestHooks({
      async afterLockCreate(path) {
        if (path !== `${receiptsPath}.lock`) return;
        migrationLocked();
        await migrationGate;
      },
    });

    const migrating = migrateLegacyVapiHome({
      legacyDirectory,
      targetDirectory,
      notice: () => undefined,
    });
    await migrationLock;
    const appending = appendReceipt(
      {
        id: "current-receipt",
        timestamp: "2026-09-30T10:01:00.000Z",
        resourceUrl: "https://api.example/current",
      },
      receiptsPath,
    );
    releaseMigration();
    await Promise.all([migrating, appending]);

    await expect(readReceipts(receiptsPath)).resolves.toEqual([
      legacyReceipt,
      {
        id: "current-receipt",
        timestamp: "2026-09-30T10:01:00.000Z",
        resourceUrl: "https://api.example/current",
      },
    ]);
  });
});
