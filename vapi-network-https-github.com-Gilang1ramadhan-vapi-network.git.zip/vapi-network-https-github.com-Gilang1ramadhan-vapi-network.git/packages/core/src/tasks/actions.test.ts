import { mkdtemp, readFile, rm, stat, writeFile } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";

import { privateKeyToAccount } from "viem/accounts";
import { afterEach, describe, expect, it, vi } from "vitest";

import { readSpendLedger, reserveSpend } from "../spend-policy.js";
import {
  autoReleaseDecision,
  deliverTask,
  disputeTask,
  fundTask,
  prepareDelivery,
  refundTask,
  releaseTask,
  signScope,
} from "./actions.js";
import { canonicalJson } from "./canonical-json.js";
import {
  missingTasksChain,
  TasksChainError,
  type TasksChain,
  type TasksChainResult,
} from "./chain-port.js";
import { createTasksClient } from "./client.js";
import { prepareDeliveryManifest, sha256Hex } from "./delivery-manifest.js";
import { taskFeeReservationKey } from "./dispute-fee.js";
import { createPendingTransactions, type PendingTransactions } from "./pending-transactions.js";
import { freezeScopeTerms } from "./scope-terms.js";
import { tasksResponseSchemas } from "./types.js";

const ORDER = "11111111-1111-4111-8111-111111111111";
const ESCROW = "22222222-2222-4222-8222-222222222222";
const FILE = "33333333-3333-4333-8333-333333333333";
const KEY = "aaaaaaaa-aaaa-4aaa-8aaa-aaaaaaaaaaaa";
const CREATE_KEY = "bbbbbbbb-bbbb-4bbb-8bbb-bbbbbbbbbbbb";
const ADDRESS = "0x1111111111111111111111111111111111111111";
const HASH = `0x${"ab".repeat(32)}` as const;
const signingAccount = privateKeyToAccount(`0x${"11".repeat(32)}`);
const proposingAccount = privateKeyToAccount(`0x${"22".repeat(32)}`);
const foreignAccount = privateKeyToAccount(`0x${"33".repeat(32)}`);
const NOW = "2026-10-08T12:00:00.000Z";
const directories: string[] = [];

const terms = {
  version: "work-milestone-terms-v1",
  title: "Prepare a report",
  description: "Write a useful report.",
  acceptanceCriteria: ["Report complete"],
  acceptanceWindowSeconds: 3600,
  budget: {
    network: "eip155:84532",
    asset: `eip155:84532/erc20:${ADDRESS}`,
    amountBaseUnits: "100000000",
  },
  escrow: { protocol: "escrow-v1", contract: ADDRESS },
  evidenceRules: { acceptedInputs: ["text"], exactCommitRequired: false },
};

const structuredTerms = {
  ...terms,
  deliverables: ["A report"],
  revisionCount: 0,
  deadline: NOW,
};
const brief = "Report";
const frozenScope = freezeScopeTerms(structuredTerms, brief);
const signingPayload = (version = 1, ordinal = 1) => ({
  version: "work-scope-signature-v1",
  workOrderId: ORDER,
  trancheOrdinal: ordinal,
  scopeVersion: version,
  termsHash: frozenScope.termsHash,
});
const SIGNATURE = await signingAccount.signMessage({ message: canonicalJson(signingPayload()) });
const proposerSignatures = new Map([
  [1, await proposingAccount.signMessage({ message: canonicalJson(signingPayload()) })],
  [2, await proposingAccount.signMessage({ message: canonicalJson(signingPayload(2)) })],
]);

function orderResponse(
  amountBaseUnits = "100000000",
  role = "client",
  escrowState: "created" | null = "created",
) {
  const response = tasksResponseSchemas.getOrder.parse({
    workOrder: {
      version: "work-order-view-v1",
      id: ORDER,
      state: "awarded",
      title: "Prepare a report",
      description: "Write a useful report.",
      policyFamily: "research-data",
      listingDeliveryTimeSeconds: null,
      clientAddress: role === "client" ? signingAccount.address : proposingAccount.address,
      invitedProviderAddress: null,
      acceptedProposalId: FILE,
      threadId: FILE,
      role,
      canFinalize: false,
      proposals: [],
      events: [],
      review: null,
      publishedAt: NOW,
      completedAt: null,
      createdAt: NOW,
      updatedAt: NOW,
      milestones: [
        {
          id: ESCROW,
          workOrderId: ORDER,
          ordinal: 1,
          state: "agreed",
          terms,
          termsHash: frozenScope.termsHash,
          termsFrozenAt: NOW,
          network: "eip155:84532",
          asset: `eip155:84532/erc20:${ADDRESS}`,
          amountBaseUnits,
          escrowProtocol: "escrow-v1",
          escrowContract: ADDRESS,
          escrowState,
          resolution: null,
          offerDeadlineAt: null,
          workDeadlineAt: null,
          acceptanceDeadlineAt: null,
          dispute: null,
          chainOperation: null,
          artifact: null,
          delivery: null,
          fundingTxHash: null,
          settlementTxHash: null,
          fundedAt: null,
          deliveredAt: null,
          settledAt: null,
          createdAt: NOW,
          updatedAt: NOW,
        },
      ],
    },
  });
  if (response.workOrder.version !== "work-order-view-v1") throw new Error("Fixture is private");
  response.workOrder.proposals = [
    {
      id: FILE,
      providerAddress: role === "provider" ? signingAccount.address : proposingAccount.address,
    } as (typeof response.workOrder.proposals)[number],
  ];
  return { ...response, workOrder: response.workOrder };
}

function scope(proposedByRole: "client" | "provider" = "client", version = 1) {
  return tasksResponseSchemas.getScopes.parse({
    scopes: [
      {
        id: FILE,
        workOrderId: ORDER,
        trancheOrdinal: 1,
        version,
        state: "proposed",
        structuredTerms,
        brief,
        termsHash: frozenScope.termsHash,
        proposedByRole,
        proposerAddress: proposingAccount.address,
        proposerSignature: proposerSignatures.get(version)!,
        counterpartyAddress: null,
        counterpartySignature: null,
        acceptedAt: null,
        milestoneId: null,
        createdAt: NOW,
        signingPayload: {
          version: "work-scope-signature-v1",
          workOrderId: ORDER,
          trancheOrdinal: 1,
          scopeVersion: version,
          termsHash: frozenScope.termsHash,
        },
      },
    ],
  }).scopes[0]!;
}

function chainResult(): TasksChainResult {
  return {
    txHash: HASH,
    operation: tasksResponseSchemas.fundEscrow.parse({
      operation: {
        id: FILE,
        kind: "escrow-funding",
        state: "confirmed",
        step: "fund-with-authorization",
        expectedActor: ADDRESS,
        transactionHash: HASH,
        plan: null,
      },
      milestone: { id: ESCROW, workOrderId: ORDER },
    }).operation,
    milestone: {
      id: ESCROW,
      workOrderId: ORDER,
      state: "funded",
      escrowState: "locked",
      resolution: null,
    },
  };
}

function dependencies(amount = "100000000") {
  const client = {
    ...createTasksClient({
      baseUrl: "https://tasks.example",
      fetch: vi.fn().mockRejectedValue(new Error("Unexpected transport")),
    }),
    getOrder: vi.fn().mockResolvedValue(orderResponse(amount)),
    deployment: vi.fn().mockResolvedValue({ configured: false, feeBp: 500 }),
    uploadFile: vi.fn().mockResolvedValue({
      file: {
        id: FILE,
        purpose: "delivery",
        fileName: "stored.md",
        mimeType: "text/markdown",
        sizeBytes: 19,
        sha256: "AB".repeat(32),
        state: "ready",
        createdAt: NOW,
      },
    }),
    getScopes: vi.fn().mockResolvedValue({ scopes: [scope()] }),
    signScope: vi.fn().mockResolvedValue({
      scope: { ...scope(), state: "accepted", milestoneId: ESCROW },
      milestone: {
        id: ESCROW,
        workOrderId: ORDER,
        ordinal: 1,
        termsHash: frozenScope.termsHash,
        termsFrozenAt: NOW,
      },
    }),
  };
  const chain = {
    available: true,
    createEscrow: vi.fn().mockResolvedValue(chainResult()),
    fund: vi.fn().mockResolvedValue(chainResult()),
    deliver: vi.fn().mockResolvedValue(chainResult()),
    release: vi.fn().mockResolvedValue(chainResult()),
    refund: vi.fn().mockResolvedValue(chainResult()),
    dispute: vi.fn().mockResolvedValue(chainResult()),
    disputeFee: vi.fn().mockResolvedValue(20000000n),
    counterEvidence: vi.fn().mockResolvedValue(chainResult()),
    resolveUnmatched: vi.fn().mockResolvedValue(chainResult()),
    signScopeMessage: vi.fn(async (message: string) => signingAccount.signMessage({ message })),
    bindScope: vi.fn().mockResolvedValue(undefined),
    signingAddress: signingAccount.address,
  } satisfies TasksChain;
  const bindings = {
    get: vi.fn().mockResolvedValue(undefined),
    put: vi.fn().mockResolvedValue(undefined),
  };
  return { client, chain, bindings, orderId: ORDER, idempotencyKey: () => KEY };
}

async function funding(amount = "100000000") {
  const directory = await mkdtemp(join(tmpdir(), "vapi-task-actions-"));
  directories.push(directory);
  return {
    ...dependencies(amount),
    ledgerPath: join(directory, "spend-ledger.json"),
    wallet: "main",
    now: () => new Date(NOW),
    caps: { perCallAtomic: "1", perDayAtomic: "200000000" },
    policy: { maxPerTaskUsd: 100, approveAboveUsd: 50 },
  };
}

afterEach(async () => {
  vi.unstubAllEnvs();
  await Promise.all(
    directories.splice(0).map((directory) => rm(directory, { recursive: true, force: true })),
  );
});

describe("task funding", () => {
  it("refuses the per-task cap without creating a ledger or lock", async () => {
    const args = await funding("100000001");
    expect(await fundTask(args)).toMatchObject({ outcome: "refused", reason: "policy.perTask" });
    expect(args.chain.fund).not.toHaveBeenCalled();
    await expect(stat(args.ledgerPath)).rejects.toMatchObject({ code: "ENOENT" });
    await expect(stat(`${args.ledgerPath}.lock`)).rejects.toMatchObject({ code: "ENOENT" });
  });

  it("refuses the per-day cap without changing bytes or acquiring a held lock", async () => {
    const args = await funding();
    const raw = JSON.stringify({ date: "2026-10-08", spentAtomic: "100000001" });
    await writeFile(args.ledgerPath, raw);
    await writeFile(`${args.ledgerPath}.lock`, "held");
    expect(await fundTask(args)).toMatchObject({ outcome: "refused", reason: "policy.perDay" });
    expect(await readFile(args.ledgerPath, "utf8")).toBe(raw);
    expect(await readFile(`${args.ledgerPath}.lock`, "utf8")).toBe("held");
    expect(args.chain.fund).not.toHaveBeenCalled();
  });

  it("reports approval needed without spending or taking a lock", async () => {
    const args = await funding();
    await writeFile(`${args.ledgerPath}.lock`, "held");
    expect(await fundTask({ ...args, approval: { granted: false } })).toMatchObject({
      outcome: "approval_needed",
    });
    expect(args.chain.fund).not.toHaveBeenCalled();
    await expect(stat(args.ledgerPath)).rejects.toMatchObject({ code: "ENOENT" });
  });

  it("reserves escrow funding immediately before the chain call with the same key", async () => {
    const args = await funding();
    args.chain.fund.mockImplementationOnce(async () => {
      expect(JSON.parse(await readFile(args.ledgerPath, "utf8"))).toMatchObject({
        spentAtomic: "100000000",
        reservations: [{ id: KEY, amountAtomic: "100000000", kind: "escrow-funding" }],
      });
      return chainResult();
    });
    expect(await fundTask({ ...args, approval: { granted: true } })).toMatchObject({
      outcome: "done",
    });
    expect(args.chain.fund).toHaveBeenCalledExactlyOnceWith({
      orderId: ORDER,
      escrowId: ESCROW,
      grossBaseUnits: 100000000n,
      idempotencyKey: KEY,
    });
  });

  it("reuses the durable reservation id for funding reruns", async () => {
    const args = await funding();
    const pending = {
      existingReservationId: vi.fn().mockResolvedValue(undefined),
      reservationId: vi.fn().mockResolvedValue(CREATE_KEY),
      withFundingLock: vi.fn(async (_id, action) => action()),
    } as unknown as import("./pending-transactions.js").PendingTransactions;
    await fundTask({ ...args, pending, approval: { granted: true } });
    expect(pending.reservationId).toHaveBeenCalledExactlyOnceWith(ESCROW, expect.any(Function));
    expect(args.chain.fund).toHaveBeenCalledWith(
      expect.objectContaining({ idempotencyKey: CREATE_KEY }),
    );
  });

  it("retries an exposed funding reservation with the same key and no double count", async () => {
    const args = await funding();
    const pending = createPendingTransactions(join(args.ledgerPath, ".."));
    args.chain.fund
      .mockImplementationOnce(async () => {
        await pending.markExposure(ESCROW);
        throw new TasksChainError("Submission uncertain", true);
      })
      .mockResolvedValueOnce(chainResult());
    await expect(fundTask({ ...args, pending, approval: { granted: true } })).rejects.toThrow(
      "Submission uncertain",
    );
    expect(await readSpendLedger(args.ledgerPath, new Date(NOW))).toMatchObject({
      spentAtomic: "100000000",
    });
    await expect(
      fundTask({ ...args, pending, approval: { granted: true } }),
    ).resolves.toMatchObject({
      outcome: "done",
    });
    expect(await readSpendLedger(args.ledgerPath, new Date(NOW))).toMatchObject({
      spentAtomic: "100000000",
    });
    expect(args.chain.fund.mock.calls[0]![0].idempotencyKey).toBe(
      args.chain.fund.mock.calls[1]![0].idempotencyKey,
    );
  });

  it("reuses one real pending reservation after authorization exposure without double counting", async () => {
    const args = await funding();
    const home = join(args.ledgerPath, "..");
    vi.stubEnv("VAPI_HOME", home);
    const pending = createPendingTransactions(home);
    const generatedKeys = vi.fn().mockReturnValueOnce(KEY).mockReturnValueOnce(CREATE_KEY);
    args.chain.fund
      .mockRejectedValueOnce(
        new TasksChainError("Authorization exposed before broadcast", false, {
          authorizationExposed: true,
        }),
      )
      .mockResolvedValueOnce(chainResult());

    await expect(
      fundTask({ ...args, pending, idempotencyKey: generatedKeys, approval: { granted: true } }),
    ).rejects.toMatchObject({
      message: "Authorization exposed before broadcast",
      authorizationExposed: true,
      broadcast: false,
    });
    const firstLedger = JSON.parse(await readFile(args.ledgerPath, "utf8"));
    expect(firstLedger.spentAtomic).toBe("100000000");
    expect(firstLedger.reservations).toHaveLength(1);
    expect(firstLedger.reservations[0]).toMatchObject({
      id: KEY,
      amountAtomic: "100000000",
      kind: "escrow-funding",
    });
    expect(await pending.existingReservationId!(ESCROW)).toBe(KEY);

    const reopenedPending = createPendingTransactions(home);
    await expect(
      fundTask({
        ...args,
        pending: reopenedPending,
        idempotencyKey: generatedKeys,
        approval: { granted: true },
      }),
    ).resolves.toMatchObject({ outcome: "done" });
    const secondLedger = JSON.parse(await readFile(args.ledgerPath, "utf8"));
    expect(secondLedger.spentAtomic).toBe("100000000");
    expect(secondLedger.reservations).toHaveLength(1);
    expect(secondLedger.reservations[0].id).toBe(firstLedger.reservations[0].id);
    expect(await reopenedPending.existingReservationId!(ESCROW)).toBe(KEY);
    expect(args.chain.fund.mock.calls[1]![0].idempotencyKey).toBe(
      args.chain.fund.mock.calls[0]![0].idempotencyKey,
    );
    expect(generatedKeys).toHaveBeenCalledOnce();
  });

  it("refuses a second milestone when earlier funding consumed the order task cap", async () => {
    const args = await funding();
    const home = join(args.ledgerPath, "..");
    const pending = createPendingTransactions(home);
    const generatedKeys = vi.fn().mockReturnValueOnce(KEY).mockReturnValue(CREATE_KEY);
    const response = orderResponse();
    if (response.workOrder.version !== "work-order-view-v1") throw new Error("Fixture is private");
    response.workOrder.milestones.push({
      ...response.workOrder.milestones[0]!,
      id: FILE,
      ordinal: 2,
      amountBaseUnits: "20000000",
    });
    args.client.getOrder.mockResolvedValue(response);

    await expect(
      fundTask({
        ...args,
        pending,
        idempotencyKey: generatedKeys,
        escrowId: ESCROW,
        approval: { granted: true },
      }),
    ).resolves.toMatchObject({ outcome: "done" });
    const before = await readFile(args.ledgerPath, "utf8");
    await expect(
      fundTask({
        ...args,
        pending,
        idempotencyKey: generatedKeys,
        escrowId: FILE,
        approval: { granted: true },
      }),
    ).resolves.toMatchObject({ outcome: "refused", reason: "policy.perTask" });
    expect(args.chain.fund).toHaveBeenCalledTimes(1);
    expect(await readFile(args.ledgerPath, "utf8")).toBe(before);
    expect(await pending.existingReservationId!(FILE)).toBeUndefined();
  });

  it("serializes concurrent funding across independent pending store instances", async () => {
    const args = await funding();
    const home = join(args.ledgerPath, "..");
    const firstPending = createPendingTransactions(home);
    const secondPending = createPendingTransactions(home);
    let active = 0;
    let highest = 0;
    args.chain.fund.mockImplementation(async () => {
      active += 1;
      highest = Math.max(highest, active);
      await new Promise((resolve) => setTimeout(resolve, 20));
      active -= 1;
      return chainResult();
    });
    await Promise.all([
      fundTask({ ...args, pending: firstPending, approval: { granted: true } }),
      fundTask({ ...args, pending: secondPending, approval: { granted: true } }),
    ]);
    expect(highest).toBe(1);
    expect(args.chain.fund).toHaveBeenCalledTimes(2);
    expect(await readSpendLedger(args.ledgerPath, new Date(NOW))).toMatchObject({
      spentAtomic: "100000000",
    });
  });

  it("can reserve the same durable id again after a proven-safe rollback", async () => {
    const args = await funding();
    const pending = createPendingTransactions(join(args.ledgerPath, ".."));
    args.chain.fund
      .mockRejectedValueOnce(
        new TasksChainError("Signing refused", false, { authorizationExposed: false }),
      )
      .mockResolvedValueOnce(chainResult());
    await expect(fundTask({ ...args, pending, approval: { granted: true } })).rejects.toThrow(
      "Signing refused",
    );
    expect(await readSpendLedger(args.ledgerPath, new Date(NOW))).toMatchObject({
      spentAtomic: "0",
    });
    await expect(
      fundTask({ ...args, pending, approval: { granted: true } }),
    ).resolves.toMatchObject({
      outcome: "done",
    });
    expect(await readSpendLedger(args.ledgerPath, new Date(NOW))).toMatchObject({
      spentAtomic: "100000000",
    });
  });

  it("retains spend when execution stops immediately after reservation invalidation", async () => {
    const args = await funding();
    const stored = createPendingTransactions(join(args.ledgerPath, ".."));
    const pending: PendingTransactions = {
      ...stored,
      async invalidateReservation(escrowId) {
        await stored.invalidateReservation?.(escrowId);
        throw new Error("Simulated crash after invalidation");
      },
    };
    args.chain.fund.mockRejectedValueOnce(
      new TasksChainError("Signing refused", false, { authorizationExposed: false }),
    );
    await expect(fundTask({ ...args, pending, approval: { granted: true } })).rejects.toMatchObject(
      {
        name: "AggregateError",
        message: "Task funding failed and its spend reservation could not be released.",
      },
    );
    expect(await readSpendLedger(args.ledgerPath, new Date(NOW))).toMatchObject({
      spentAtomic: "100000000",
    });
    expect(await stored.retainedReservation?.(ESCROW)).toMatchObject({ invalidated: true });
  });

  it("persists reservation metadata before the chain call and resumes it across UTC days", async () => {
    const args = await funding();
    const home = join(args.ledgerPath, "..");
    const pending = createPendingTransactions(home);
    args.chain.fund.mockImplementationOnce(async () => {
      expect(await pending.retainedReservation?.(ESCROW)).toMatchObject({
        wallet: "main",
        amountAtomic: "100000000",
        date: "2026-10-08",
      });
      await pending.markExposure(ESCROW);
      throw new TasksChainError("Submission uncertain", true);
    });
    await expect(fundTask({ ...args, pending, approval: { granted: true } })).rejects.toThrow(
      "Submission uncertain",
    );
    const nextDay = new Date("2026-10-09T12:00:00.000Z");
    await writeFile(
      args.ledgerPath,
      JSON.stringify({ date: "2026-10-09", spentAtomic: "200000000" }),
    );
    args.chain.fund.mockResolvedValueOnce(chainResult());
    await expect(
      fundTask({ ...args, pending, now: () => nextDay, approval: { granted: true } }),
    ).resolves.toMatchObject({ outcome: "done" });
    expect(await readSpendLedger(args.ledgerPath, nextDay)).toMatchObject({
      spentAtomic: "200000000",
    });
  });

  it("never reserves against an unavailable chain", async () => {
    const args = await funding();
    await expect(
      fundTask({ ...args, chain: missingTasksChain, approval: { granted: true } }),
    ).rejects.toThrow("An acting wallet is required for task chain operations.");
    await expect(stat(args.ledgerPath)).rejects.toMatchObject({ code: "ENOENT" });
    const raw = JSON.stringify({ date: "2026-10-08", spentAtomic: "1000" });
    await writeFile(args.ledgerPath, raw);
    await expect(
      fundTask({ ...args, chain: missingTasksChain, approval: { granted: true } }),
    ).rejects.toThrow("An acting wallet is required for task chain operations.");
    expect(await readFile(args.ledgerPath, "utf8")).toBe(raw);
  });

  it("rolls back only a failure that proves no authorization was exposed or transaction broadcast", async () => {
    const args = await funding();
    args.chain.fund.mockRejectedValueOnce(
      new TasksChainError("Signing refused", false, { authorizationExposed: false }),
    );
    await expect(fundTask({ ...args, approval: { granted: true } })).rejects.toThrow(
      "Signing refused",
    );
    expect(await readSpendLedger(args.ledgerPath, new Date(NOW))).toMatchObject({
      spentAtomic: "0",
    });
    expect(JSON.parse(await readFile(args.ledgerPath, "utf8")).reservations).toBeUndefined();
  });

  it.each([
    new Error("Preparation response lost after authorization submission"),
    new TasksChainError("Preparation rejected after authorization submission", false),
    new TasksChainError("Authorization may have reached the server", false, {
      authorizationExposed: true,
    }),
    new TasksChainError("Transaction submitted", true, { authorizationExposed: false }),
  ])("retains funding headroom on an unsafe or unknown failure: %s", async (error) => {
    const args = await funding();
    args.chain.fund.mockRejectedValueOnce(error);
    await expect(fundTask({ ...args, approval: { granted: true } })).rejects.toBe(error);
    expect(JSON.parse(await readFile(args.ledgerPath, "utf8"))).toMatchObject({
      spentAtomic: "100000000",
      reservations: [{ id: KEY, amountAtomic: "100000000", kind: "escrow-funding" }],
    });
    expect(
      await fundTask({
        ...args,
        caps: { ...args.caps, perDayAtomic: "199999999" },
        policy: { ...args.policy, maxPerTaskUsd: 200 },
        approval: { granted: true },
        idempotencyKey: () => CREATE_KEY,
      }),
    ).toMatchObject({ outcome: "refused", reason: "policy.perDay" });
    expect(args.chain.fund).toHaveBeenCalledTimes(1);
  });

  it("retains a reservation on a possibly broadcast failure", async () => {
    const args = await funding();
    args.chain.fund.mockRejectedValueOnce(new TasksChainError("Submission uncertain", true));
    await expect(fundTask({ ...args, approval: { granted: true } })).rejects.toThrow(
      "Submission uncertain",
    );
    expect(await readSpendLedger(args.ledgerPath, new Date(NOW))).toMatchObject({
      spentAtomic: "100000000",
    });
  });

  it("declines or propagates failed approval without a reservation", async () => {
    const args = await funding();
    const ask = vi.fn().mockResolvedValue(false);
    expect(await fundTask({ ...args, approval: { ask } })).toMatchObject({ outcome: "declined" });
    expect(ask).toHaveBeenCalledWith(
      expect.objectContaining({
        dayRemainingUsd: 200,
        money: expect.objectContaining({ feeBp: 500 }),
      }),
    );
    ask.mockRejectedValueOnce(new Error("Prompt failed"));
    await expect(fundTask({ ...args, approval: { ask } })).rejects.toThrow("Prompt failed");
    await expect(stat(args.ledgerPath)).rejects.toMatchObject({ code: "ENOENT" });
  });

  it("uses no fee when readiness omits it or fails", async () => {
    const args = await funding();
    args.client.deployment.mockResolvedValueOnce({ configured: false, feeBp: null });
    expect(await fundTask(args)).toMatchObject({
      money: {
        feeBp: null,
        fee: null,
        net: null,
        line: "$100.00 gross · fee unavailable",
      },
    });
    args.client.deployment.mockResolvedValueOnce({ configured: false });
    expect(await fundTask(args)).toMatchObject({
      money: { feeBp: null, line: "$100.00 gross · fee unavailable" },
    });
    args.client.deployment.mockRejectedValueOnce(new Error("Readiness unavailable"));
    expect(await fundTask(args)).toMatchObject({ money: { feeBp: null, fee: null, net: null } });
  });

  it("requires an explicit milestone on an order with multiple tranches", async () => {
    const args = await funding();
    const response = orderResponse();
    if (response.workOrder.version !== "work-order-view-v1") throw new Error("Fixture is private");
    response.workOrder.milestones.push({
      ...response.workOrder.milestones[0]!,
      id: FILE,
      ordinal: 2,
    });
    args.client.getOrder.mockResolvedValue(response);
    await expect(fundTask(args)).rejects.toThrow("milestone");
    expect(await fundTask({ ...args, escrowId: ESCROW })).toMatchObject({
      outcome: "approval_needed",
    });
    expect(args.chain.fund).not.toHaveBeenCalled();
  });

  it("rejects a foreign milestone or returned order before spending", async () => {
    const args = await funding();
    await expect(fundTask({ ...args, escrowId: FILE })).rejects.toThrow();
    const response = orderResponse();
    response.workOrder.id = FILE;
    args.client.getOrder.mockResolvedValueOnce(response);
    await expect(fundTask(args)).rejects.toThrow();
    await expect(stat(args.ledgerPath)).rejects.toMatchObject({ code: "ENOENT" });
  });

  it("rechecks the daily cap atomically after approval and isolates wallets", async () => {
    const args = await funding();
    const ask = async () => {
      await reserveSpend(100000001n, args.caps, {
        ledgerPath: args.ledgerPath,
        now: new Date(NOW),
        kind: "escrow-funding",
        maxPerTaskAtomic: 200000000n,
      });
      return true;
    };
    await expect(fundTask({ ...args, approval: { ask } })).rejects.toMatchObject({
      code: "per_day_cap_exceeded",
    });
    expect(args.chain.fund).not.toHaveBeenCalled();
    expect(
      await fundTask({ ...args, wallet: "worker", approval: { granted: true } }),
    ).toMatchObject({ outcome: "done" });
  });

  it("floors fractional policy caps and rejects unsafe operation keys before reserving", async () => {
    const args = await funding("1");
    expect(
      await fundTask({ ...args, policy: { maxPerTaskUsd: 9e-7, approveAboveUsd: 0 } }),
    ).toMatchObject({ outcome: "refused", reason: "policy.perTask" });
    await expect(
      fundTask({ ...args, approval: { granted: true }, idempotencyKey: () => "bad-key" }),
    ).rejects.toThrow();
    await expect(stat(args.ledgerPath)).rejects.toMatchObject({ code: "ENOENT" });
    expect(args.chain.fund).not.toHaveBeenCalled();
  });

  it("refuses duplicate reservations without broadcasting a retry", async () => {
    const args = await funding();
    const policy = { ...args.policy, maxPerTaskUsd: 200 };
    await fundTask({ ...args, policy, approval: { granted: true } });
    const bytes = await readFile(args.ledgerPath, "utf8");
    await expect(fundTask({ ...args, policy, approval: { granted: true } })).rejects.toThrow(
      "already exists",
    );
    expect(args.chain.fund).toHaveBeenCalledTimes(1);
    expect(await readFile(args.ledgerPath, "utf8")).toBe(bytes);
  });
});

describe("task delivery", () => {
  const files = [
    { path: "/out/local.md", bytes: new Uint8Array([1, 2]), contentType: "text/markdown" as const },
  ];

  it("builds the manifest from finalized upload metadata and passes it to the chain", async () => {
    const args = dependencies();
    const manifest = await prepareDeliveryManifest(
      [{ fileId: FILE, fileName: "stored.md", sha256: "AB".repeat(32), sizeBytes: 19 }],
      "Exact note ",
    );
    const result = await deliverTask({ ...args, files, note: "Exact note " });
    expect(result.manifestHash).toBe(manifest.manifestHash);
    expect(args.client.uploadFile).toHaveBeenCalledExactlyOnceWith({
      fileName: "local.md",
      bytes: files[0]!.bytes,
      contentType: "text/markdown",
      purpose: "delivery",
    });
    expect(args.chain.deliver).toHaveBeenCalledExactlyOnceWith({
      orderId: ORDER,
      escrowId: ESCROW,
      manifest,
      note: "Exact note ",
      idempotencyKey: KEY,
    });
  });

  it("reuses saved delivery file IDs only when note and local file content match", async () => {
    const args = dependencies();
    const home = await mkdtemp(join(tmpdir(), "vapi-delivery-"));
    directories.push(home);
    const pending = createPendingTransactions(home);
    const note = "Exact note";
    const manifest = await prepareDeliveryManifest(
      [
        {
          fileId: FILE,
          fileName: "local.md",
          sha256: await sha256Hex(files[0]!.bytes),
          sizeBytes: files[0]!.bytes.byteLength,
        },
      ],
      note,
    );
    await pending.putPreparation(ESCROW, "deliver", {
      idempotencyKey: KEY,
      inputs: { manifestHash: manifest.manifestHash, manifest: manifest.manifest, note },
    });
    await expect(deliverTask({ ...args, pending, files, note })).resolves.toMatchObject({
      manifestHash: manifest.manifestHash,
    });
    expect(args.client.uploadFile).not.toHaveBeenCalled();
    expect(args.chain.deliver).toHaveBeenCalledWith(expect.objectContaining({ manifest, note }));
    await expect(deliverTask({ ...args, pending, files, note: `${note}!` })).rejects.toThrow(
      "does not match",
    );
    await expect(
      deliverTask({
        ...args,
        pending,
        files: [{ ...files[0]!, bytes: new Uint8Array([1, 3]) }],
        note,
      }),
    ).rejects.toThrow("does not match");
    expect(args.client.uploadFile).not.toHaveBeenCalled();
  });

  it("exposes the computed hash even when the chain is unavailable", async () => {
    const args = dependencies();
    const prepared = await prepareDelivery({ ...args, files, note: "Report" });
    await expect(
      deliverTask({ ...args, chain: missingTasksChain, files, note: "Report" }),
    ).rejects.toMatchObject({
      code: "chain_unavailable",
      manifestHash: prepared.manifest.manifestHash,
    });
  });

  it("does not call the chain after an upload failure or invalid note", async () => {
    const args = dependencies();
    await expect(deliverTask({ ...args, files, note: " " })).rejects.toThrow();
    expect(args.client.uploadFile).not.toHaveBeenCalled();
    args.client.uploadFile.mockRejectedValueOnce(new Error("Upload failed"));
    await expect(deliverTask({ ...args, files, note: "Report" })).rejects.toThrow("Upload failed");
    expect(args.chain.deliver).not.toHaveBeenCalled();
  });
});

describe("explicit settlement and dispute", () => {
  it("refuses a dispute fee after fundTask consumes the work order task cap", async () => {
    const args = await funding();
    const pending = createPendingTransactions(join(args.ledgerPath, ".."));
    const generatedKeys = vi.fn().mockReturnValueOnce(KEY).mockReturnValue(CREATE_KEY);
    const shared = {
      ...args,
      pending,
      caps: { perCallAtomic: "1", perDayAtomic: "200000000" },
      idempotencyKey: generatedKeys,
    };
    await expect(fundTask({ ...shared, approval: { granted: true } })).resolves.toMatchObject({
      outcome: "done",
    });
    const before = await readFile(args.ledgerPath, "utf8");

    await expect(disputeTask({ ...shared, evidenceHash: HASH })).resolves.toMatchObject({
      outcome: "refused",
      reason: "policy.perTask",
    });
    expect(args.chain.dispute).not.toHaveBeenCalled();
    expect(await readFile(args.ledgerPath, "utf8")).toBe(before);
    expect(
      await pending.existingReservationId!(taskFeeReservationKey(ESCROW, "dispute")),
    ).toBeUndefined();
  });

  it("computes money then releases or refunds without a policy gate", async () => {
    const args = dependencies();
    expect(await releaseTask(args)).toMatchObject({
      money: { gross: { baseUnits: "100000000" } },
      result: { txHash: HASH },
    });
    expect(await refundTask(args)).toMatchObject({ money: { feeBp: 500 } });
    expect(args.chain.release).toHaveBeenCalledExactlyOnceWith({
      orderId: ORDER,
      escrowId: ESCROW,
      idempotencyKey: KEY,
    });
    expect(args.chain.refund).toHaveBeenCalledExactlyOnceWith({
      orderId: ORDER,
      escrowId: ESCROW,
      idempotencyKey: KEY,
    });
  });

  it("reports the verified contract dispute fee and validates evidence", async () => {
    const args = await funding();
    expect(await disputeTask({ ...args, evidenceHash: HASH })).toMatchObject({
      outcome: "done",
      disputeFee: { baseUnits: "20000000", usd: "20.00" },
    });
    expect(args.chain.dispute).toHaveBeenCalledExactlyOnceWith({
      orderId: ORDER,
      escrowId: ESCROW,
      evidenceHash: HASH,
      feeBaseUnits: 20000000n,
      beforeSign: expect.any(Function),
      idempotencyKey: KEY,
    });
    await expect(disputeTask({ ...args, evidenceHash: "0x1234" })).rejects.toThrow();
    expect(args.chain.dispute).toHaveBeenCalledTimes(1);
  });

  it("requires approval at the automatic release threshold", () => {
    expect(autoReleaseDecision({ amountUsd: 24.999999, autoReleaseBelowUsd: 25 })).toEqual({
      auto: true,
    });
    expect(autoReleaseDecision({ amountUsd: 25, autoReleaseBelowUsd: 25 })).toEqual({
      approval: true,
    });
  });
});

describe("scope acceptance", () => {
  it.each(["poster", "worker"] as const)(
    "refuses a valid %s signature from a wallet other than the locally derived party",
    async (role) => {
      const args = dependencies();
      args.client.getOrder.mockResolvedValue(
        orderResponse("100000000", role === "poster" ? "client" : "provider", null),
      );
      args.client.getScopes.mockResolvedValueOnce({
        scopes: [scope(role === "poster" ? "provider" : "client")],
      });
      const signMessage = vi.fn((message: string) => foreignAccount.signMessage({ message }));
      const chain = { ...args.chain, signingAddress: foreignAccount.address };
      await expect(signScope({ ...args, chain, role, signMessage })).rejects.toThrow(
        /local.*signature|task party|signing wallet/i,
      );
      expect(signMessage).toHaveBeenCalledOnce();
      expect(args.bindings.put).not.toHaveBeenCalled();
      expect(args.client.signScope).not.toHaveBeenCalled();
    },
  );

  it("refuses accepted worker recovery when local self is not the accepted provider", async () => {
    const args = dependencies();
    const response = orderResponse("100000000", "provider", null);
    response.workOrder.proposals[0]!.providerAddress = foreignAccount.address;
    args.client.getOrder.mockResolvedValue(response);
    args.client.getScopes.mockResolvedValueOnce({
      scopes: [
        {
          ...scope(),
          state: "accepted",
          counterpartyAddress: signingAccount.address,
          counterpartySignature: SIGNATURE,
          acceptedAt: NOW,
          milestoneId: ESCROW,
        },
      ],
    });
    await expect(
      signScope({ ...args, role: "worker", counterparty: proposingAccount.address }),
    ).rejects.toThrow(/accepted provider|task party|signing wallet/i);
    expect(args.bindings.put).not.toHaveBeenCalled();
    expect(args.chain.createEscrow).not.toHaveBeenCalled();
    expect(args.client.signScope).not.toHaveBeenCalled();
  });

  it("recovers accepted worker scope using the asynchronous local signer address", async () => {
    const args = dependencies();
    args.client.getOrder.mockResolvedValue(orderResponse("100000000", "provider", null));
    args.client.getScopes.mockResolvedValue({
      scopes: [
        {
          ...scope(),
          state: "accepted",
          milestoneId: ESCROW,
          counterpartyAddress: signingAccount.address,
          counterpartySignature: SIGNATURE,
          acceptedAt: NOW,
        },
      ],
    });
    const chain = {
      ...args.chain,
      signingAddress: undefined,
      getSigningAddress: vi.fn().mockResolvedValue(signingAccount.address),
    };
    await signScope({ ...args, chain, role: "worker", counterparty: proposingAccount.address });
    expect(chain.getSigningAddress).toHaveBeenCalledOnce();
    expect(chain.createEscrow).toHaveBeenCalledOnce();
    expect(chain.signScopeMessage).not.toHaveBeenCalled();
  });
  it("recovers accepted worker scope when the local wallet proposed it", async () => {
    const args = dependencies();
    args.client.getOrder.mockResolvedValue(orderResponse("100000000", "provider", null));
    args.client.getScopes.mockResolvedValue({
      scopes: [
        {
          ...scope("provider"),
          state: "accepted",
          milestoneId: ESCROW,
          proposerAddress: signingAccount.address,
          proposerSignature: SIGNATURE,
          counterpartyAddress: proposingAccount.address,
          counterpartySignature: proposerSignatures.get(1)!,
          acceptedAt: NOW,
        },
      ],
    });
    await signScope({ ...args, role: "worker", counterparty: proposingAccount.address });
    expect(args.chain.createEscrow).toHaveBeenCalledOnce();
    expect(args.chain.signScopeMessage).not.toHaveBeenCalled();
  });
  it("requires explicit counterparty confirmation for accepted worker scope without a local binding", async () => {
    const args = dependencies();
    args.client.getOrder.mockResolvedValue(orderResponse("100000000", "provider", null));
    args.client.getScopes.mockResolvedValue({
      scopes: [
        {
          ...scope(),
          state: "accepted",
          milestoneId: ESCROW,
          counterpartyAddress: signingAccount.address,
          counterpartySignature: SIGNATURE,
          acceptedAt: NOW,
        },
      ],
    });
    await expect(signScope({ ...args, role: "worker" })).rejects.toThrow(
      "The task parties are not bound on this machine. Re-run with --counterparty <address> to confirm who you are working with.",
    );
    expect(args.chain.createEscrow).not.toHaveBeenCalled();
    expect(args.chain.signScopeMessage).not.toHaveBeenCalled();
  });

  it("resumes accepted worker escrow creation from the persisted local binding without another scope signature", async () => {
    const args = dependencies();
    args.client.getOrder.mockResolvedValue(orderResponse("100000000", "provider", null));
    args.client.getScopes.mockResolvedValue({
      scopes: [
        {
          ...scope(),
          state: "accepted",
          milestoneId: ESCROW,
          counterpartyAddress: signingAccount.address,
          counterpartySignature: SIGNATURE,
          acceptedAt: NOW,
        },
      ],
    });
    args.bindings.get.mockResolvedValue({
      orderId: ORDER,
      trancheOrdinal: 1,
      scopeVersion: 1,
      termsHash: frozenScope.termsHash,
      role: "provider",
      self: signingAccount.address,
      counterparty: proposingAccount.address,
      signedAt: NOW,
    });
    await signScope({ ...args, role: "worker" });
    expect(args.chain.createEscrow).toHaveBeenCalledExactlyOnceWith({
      orderId: ORDER,
      counterparty: proposingAccount.address,
      idempotencyKey: KEY,
    });
    expect(args.chain.signScopeMessage).not.toHaveBeenCalled();
    expect(args.client.signScope).not.toHaveBeenCalled();
  });

  it("recovers worker escrow creation from an accepted scope with an explicit counterparty and no second scope signature", async () => {
    const args = dependencies();
    args.client.getOrder.mockResolvedValue(orderResponse("100000000", "provider", null));
    args.client.getScopes.mockResolvedValue({
      scopes: [
        {
          ...scope(),
          state: "accepted",
          milestoneId: ESCROW,
          counterpartyAddress: signingAccount.address,
          counterpartySignature: SIGNATURE,
          acceptedAt: NOW,
        },
      ],
    });
    const signMessage = vi.fn().mockResolvedValue(SIGNATURE);
    const result = await signScope({
      ...args,
      role: "worker",
      counterparty: proposingAccount.address,
      signMessage,
    });
    expect(result.terms.counterparty).toBe(proposingAccount.address);
    expect(args.chain.createEscrow).toHaveBeenCalledExactlyOnceWith({
      orderId: ORDER,
      counterparty: proposingAccount.address,
      idempotencyKey: KEY,
    });
    expect(args.bindings.put).toHaveBeenCalledWith(
      expect.objectContaining({
        role: "provider",
        self: signingAccount.address,
        counterparty: proposingAccount.address,
      }),
    );
    expect(signMessage).not.toHaveBeenCalled();
    expect(args.chain.signScopeMessage).not.toHaveBeenCalled();
    expect(args.client.signScope).not.toHaveBeenCalled();
  });
  it("refuses accepted worker recovery unless the local wallet also signed the accepted scope", async () => {
    const args = dependencies();
    args.client.getOrder.mockResolvedValue(orderResponse("100000000", "provider", null));
    args.client.getScopes.mockResolvedValue({
      scopes: [
        {
          ...scope(),
          state: "accepted",
          milestoneId: ESCROW,
          counterpartyAddress: signingAccount.address,
          counterpartySignature: `0x${"00".repeat(65)}`,
          acceptedAt: NOW,
        },
      ],
    });
    await expect(
      signScope({ ...args, role: "worker", counterparty: proposingAccount.address }),
    ).rejects.toThrow(/accepted scope signatures/);
    expect(args.chain.createEscrow).not.toHaveBeenCalled();
    expect(args.chain.signScopeMessage).not.toHaveBeenCalled();
    expect(args.bindings.put).not.toHaveBeenCalled();
  });

  it("refuses an explicitly confirmed scope counterparty that differs from the proposer", async () => {
    const args = dependencies();
    args.client.getScopes.mockResolvedValueOnce({ scopes: [scope("provider")] });
    const signMessage = vi.fn().mockResolvedValue(SIGNATURE);
    await expect(
      signScope({ ...args, role: "poster", signMessage, counterparty: ADDRESS } as Parameters<
        typeof signScope
      >[0]),
    ).rejects.toThrow(/confirmed counterparty/);
    expect(signMessage).not.toHaveBeenCalled();
  });

  it("shows verified parties and persists their binding before acceptance leaves the machine", async () => {
    const args = dependencies();
    args.client.getScopes.mockResolvedValueOnce({ scopes: [scope("provider")] });
    const order: string[] = [];
    args.bindings.put.mockImplementation(async () => {
      order.push("binding");
    });
    const signMessage = vi.fn(async (message: string) => {
      order.push("signature");
      return signingAccount.signMessage({ message });
    });
    args.client.signScope.mockImplementationOnce(async () => {
      order.push("acceptance");
      return {
        scope: { ...scope("provider"), state: "accepted", milestoneId: ESCROW },
        milestone: {
          id: ESCROW,
          workOrderId: ORDER,
          ordinal: 1,
          termsHash: frozenScope.termsHash,
          termsFrozenAt: NOW,
        },
      };
    });
    await signScope({
      ...args,
      role: "poster",
      signMessage,
      onTerms: (terms) => {
        expect(terms.counterparty).toBe(proposingAccount.address);
        order.push("terms");
      },
    });
    expect(order).toEqual(["terms", "signature", "binding", "acceptance"]);
    expect(args.bindings.put).toHaveBeenCalledWith(
      expect.objectContaining({
        orderId: ORDER,
        trancheOrdinal: 1,
        scopeVersion: 1,
        termsHash: frozenScope.termsHash,
        role: "client",
        self: signingAccount.address,
        counterparty: proposingAccount.address,
      }),
    );
  });

  it("refuses an invalid counterparty scope signature before local signing", async () => {
    const args = dependencies();
    args.client.getScopes.mockResolvedValueOnce({
      scopes: [{ ...scope("provider"), proposerSignature: `0x${"00".repeat(65)}` }],
    });
    const signMessage = vi.fn().mockResolvedValue(SIGNATURE);
    await expect(signScope({ ...args, role: "poster", signMessage })).rejects.toThrow(
      /counterparty scope signature/,
    );
    expect(signMessage).not.toHaveBeenCalled();
    expect(args.client.signScope).not.toHaveBeenCalled();
  });

  it("accepts a poster scope with a local message signer and no chain adapter", async () => {
    const args = dependencies();
    args.client.getScopes.mockResolvedValueOnce({ scopes: [scope("provider")] });
    const signMessage = vi.fn().mockResolvedValue(SIGNATURE);
    expect(
      await signScope({ ...args, chain: missingTasksChain, role: "poster", signMessage }),
    ).toMatchObject({ escrowCreation: null });
    expect(signMessage).toHaveBeenCalledExactlyOnceWith(canonicalJson(scope().signingPayload));
    expect(args.client.signScope).toHaveBeenCalledExactlyOnceWith(
      FILE,
      { signedPayload: scope("provider").signingPayload, signature: SIGNATURE },
      { idempotencyKey: KEY },
    );
    expect(args.chain.signScopeMessage).not.toHaveBeenCalled();
  });

  it("preserves worker acceptance when local signing succeeds but escrow creation has no acting chain wallet", async () => {
    const args = dependencies();
    args.client.getOrder.mockResolvedValue(orderResponse("100000000", "provider", null));
    const signMessage = vi.fn().mockResolvedValue(SIGNATURE);
    await expect(
      signScope({ ...args, chain: missingTasksChain, role: "worker", signMessage }),
    ).rejects.toMatchObject({
      acceptance: { scope: { state: "accepted" } },
      cause: {
        code: "chain_unavailable",
        message: "An acting wallet is required for task chain operations.",
      },
    });
    expect(args.client.signScope).toHaveBeenCalledTimes(1);
  });

  it("does not invoke a local signer for a scope belonging to another task", async () => {
    const args = dependencies();
    args.client.getScopes.mockResolvedValueOnce({
      scopes: [{ ...scope("provider"), workOrderId: FILE }],
    });
    const signMessage = vi.fn().mockResolvedValue(SIGNATURE);
    await expect(signScope({ ...args, role: "poster", signMessage })).rejects.toThrow(
      "different task",
    );
    expect(signMessage).not.toHaveBeenCalled();
    expect(args.client.signScope).not.toHaveBeenCalled();
  });

  it("does not accept a scope when local signing fails", async () => {
    const args = dependencies();
    args.client.getScopes.mockResolvedValueOnce({ scopes: [scope("provider")] });
    const signMessage = vi.fn().mockRejectedValue(new Error("Vault signing refused"));
    await expect(signScope({ ...args, role: "poster", signMessage })).rejects.toThrow(
      "Vault signing refused",
    );
    expect(args.client.signScope).not.toHaveBeenCalled();
    expect(args.chain.createEscrow).not.toHaveBeenCalled();
  });

  it.each([
    ["brief", { ...scope(), brief: "Tampered report brief" }],
    ["malformed brief", { ...scope(), brief: " \n" }],
    [
      "structured terms",
      {
        ...scope(),
        structuredTerms: { ...scope().structuredTerms, title: "Tampered report" },
      },
    ],
    [
      "malformed terms",
      {
        ...scope(),
        structuredTerms: { ...scope().structuredTerms, title: "x" },
      },
    ],
  ])("refuses tampered %s before invoking either signer", async (_name, tampered) => {
    const args = dependencies();
    args.client.getOrder.mockResolvedValue(orderResponse("100000000", "provider", null));
    args.client.getScopes.mockResolvedValueOnce({ scopes: [tampered] });
    const signMessage = vi.fn().mockResolvedValue(SIGNATURE);

    await expect(signScope({ ...args, role: "worker", signMessage })).rejects.toMatchObject({
      message: "The scope terms do not match their hash; refusing to sign.",
    });
    expect(signMessage).not.toHaveBeenCalled();
    expect(args.chain.signScopeMessage).not.toHaveBeenCalled();
    expect(args.client.signScope).not.toHaveBeenCalled();
  });

  it("signs canonical payload bytes and reports worker escrow creation separately", async () => {
    const args = dependencies();
    args.client.getOrder.mockResolvedValue(orderResponse("100000000", "provider", null));
    const keys = vi.fn().mockReturnValueOnce(KEY).mockReturnValueOnce(CREATE_KEY);
    const result = await signScope({ ...args, role: "worker", idempotencyKey: keys });
    expect(args.chain.signScopeMessage).toHaveBeenCalledExactlyOnceWith(
      canonicalJson(scope().signingPayload),
    );
    expect(args.client.signScope).toHaveBeenCalledExactlyOnceWith(
      FILE,
      { signedPayload: scope().signingPayload, signature: SIGNATURE },
      { idempotencyKey: KEY },
    );
    expect(args.chain.createEscrow).toHaveBeenCalledExactlyOnceWith({
      orderId: ORDER,
      idempotencyKey: CREATE_KEY,
    });
    expect(result.escrowCreation).toEqual(chainResult());
    expect(result.terms).toEqual({
      role: "provider",
      self: signingAccount.address,
      direction: "you deliver work to the poster",
      counterparty: proposingAccount.address,
      amountBaseUnits: "100000000",
      asset: `eip155:84532/erc20:${ADDRESS}`,
      network: "eip155:84532",
      deadline: NOW,
      deliverables: ["A report"],
      title: "Prepare a report",
    });
  });

  it("does not create an escrow for a poster or one already created", async () => {
    const args = dependencies();
    args.client.getScopes.mockResolvedValueOnce({ scopes: [scope("provider")] });
    expect(await signScope({ ...args, role: "poster" })).toMatchObject({ escrowCreation: null });
    args.client.getOrder.mockResolvedValue(orderResponse("100000000", "provider"));
    expect(await signScope({ ...args, role: "worker" })).toMatchObject({ escrowCreation: null });
    expect(args.chain.createEscrow).not.toHaveBeenCalled();
  });

  it("rejects role, scope membership, and signing payload mismatches before signing", async () => {
    const args = dependencies();
    await expect(signScope({ ...args, role: "worker" })).rejects.toThrow();
    args.client.getScopes.mockResolvedValueOnce({
      scopes: [{ ...scope("provider"), workOrderId: FILE }],
    });
    await expect(signScope({ ...args, role: "poster" })).rejects.toThrow();
    args.client.getScopes.mockResolvedValueOnce({
      scopes: [
        {
          ...scope("provider"),
          signingPayload: { ...scope("provider").signingPayload, scopeVersion: 2 },
        },
      ],
    });
    await expect(signScope({ ...args, role: "poster" })).rejects.toThrow();
    expect(args.chain.signScopeMessage).not.toHaveBeenCalled();
  });

  it("preserves successful acceptance if later escrow creation fails", async () => {
    const args = dependencies();
    args.client.getOrder.mockResolvedValue(orderResponse("100000000", "provider", null));
    args.chain.createEscrow.mockRejectedValueOnce(new TasksChainError("Creation failed", true));
    await expect(signScope({ ...args, role: "worker" })).rejects.toMatchObject({
      acceptance: { scope: { state: "accepted" } },
      cause: new TasksChainError("Creation failed", true),
      broadcast: true,
    });
    expect(args.client.signScope).toHaveBeenCalledTimes(1);
  });

  it("chooses the current scope and rejects simultaneous proposed tranches", async () => {
    const args = dependencies();
    const latest = scope("provider", 2);
    args.client.getScopes.mockResolvedValueOnce({ scopes: [scope("provider"), latest] });
    args.client.signScope.mockResolvedValueOnce({
      scope: { ...latest, state: "accepted", milestoneId: ESCROW },
      milestone: {
        id: ESCROW,
        workOrderId: ORDER,
        ordinal: 1,
        termsHash: frozenScope.termsHash,
        termsFrozenAt: NOW,
      },
    });
    await signScope({ ...args, role: "poster" });
    expect(args.chain.signScopeMessage).toHaveBeenCalledExactlyOnceWith(
      canonicalJson(latest.signingPayload),
    );
    args.client.getScopes.mockResolvedValueOnce({
      scopes: [latest, { ...scope("provider"), id: ESCROW, trancheOrdinal: 2 }],
    });
    await expect(signScope({ ...args, role: "poster" })).rejects.toThrow("one current");
    expect(args.chain.signScopeMessage).toHaveBeenCalledTimes(1);
  });

  it("rejects a foreign acceptance before creating an escrow", async () => {
    const args = dependencies();
    args.client.getOrder.mockResolvedValue(orderResponse("100000000", "provider", null));
    args.client.signScope.mockResolvedValueOnce({
      scope: { ...scope(), state: "accepted", milestoneId: ESCROW },
      milestone: {
        id: ESCROW,
        workOrderId: FILE,
        ordinal: 1,
        termsHash: frozenScope.termsHash,
        termsFrozenAt: NOW,
      },
    });
    await expect(signScope({ ...args, role: "worker" })).rejects.toThrow("accepted scope");
    expect(args.chain.createEscrow).not.toHaveBeenCalled();
  });

  it("preserves acceptance if the refreshed order fails and avoids creating an older tranche", async () => {
    const args = dependencies();
    args.client.getOrder
      .mockResolvedValueOnce(orderResponse("100000000", "provider", null))
      .mockRejectedValueOnce(new Error("Refresh failed"));
    await expect(signScope({ ...args, role: "worker" })).rejects.toMatchObject({
      acceptance: { scope: { state: "accepted" } },
      cause: new Error("Refresh failed"),
    });
    const response = orderResponse("100000000", "provider", null);
    if (response.workOrder.version !== "work-order-view-v1") throw new Error("Fixture is private");
    response.workOrder.milestones[0]!.ordinal = 2;
    response.workOrder.milestones.push({
      ...response.workOrder.milestones[0]!,
      id: FILE,
      ordinal: 1,
    });
    const next = {
      ...scope(),
      trancheOrdinal: 2,
      proposerSignature: await proposingAccount.signMessage({
        message: canonicalJson(signingPayload(1, 2)),
      }),
      signingPayload: { ...scope().signingPayload, trancheOrdinal: 2 },
    };
    args.client.getScopes.mockResolvedValueOnce({ scopes: [next] });
    args.client.signScope.mockResolvedValueOnce({
      scope: { ...next, state: "accepted", milestoneId: ESCROW },
      milestone: {
        id: ESCROW,
        workOrderId: ORDER,
        ordinal: 2,
        termsHash: frozenScope.termsHash,
        termsFrozenAt: NOW,
      },
    });
    args.client.getOrder.mockResolvedValue(response);
    await expect(signScope({ ...args, role: "worker" })).rejects.toMatchObject({
      acceptance: { scope: { state: "accepted" } },
      cause: new Error("An earlier task milestone still needs escrow creation."),
    });
    expect(args.chain.createEscrow).not.toHaveBeenCalled();
  });
});
