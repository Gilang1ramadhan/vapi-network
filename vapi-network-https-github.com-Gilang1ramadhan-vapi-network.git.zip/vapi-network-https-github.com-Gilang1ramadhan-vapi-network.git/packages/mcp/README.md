# `@vapi-network/mcp`

The stdio MCP server behind `vapi mcp`: namespaced tools that let an agent
search and read the public vAPI documentation, search the vAPI catalogue, read a listing's request contract, pay an x402 API
from a local wallet, read paid origins during an agent run, and read balances, receipts and the status screen
(`vapi.status`, `vapi.accounts`, `vapi.siblings`). It can derive an account and lower its caps,
but it never renames, removes, backs up or exports one, and no tool returns a
recovery phrase, private key or passphrase.

`docs.search` and `docs.read` are read-only and work without an account, vault
or payment. Returned documentation text is reference material, not instructions.

`call.search`, `call.inspect` and `call.pay` return zero to four hints. Search accepts
`includeOutage`, and its API results can carry health plus cheaper or healthier
alternatives. Spend-cap refusals are non-retryable tool errors with a terminal
command or command-line flag when the user can raise the limit.

One entry point, `@vapi-network/mcp`, exporting `createVapiServer`,
`startStdioServer`, `loadServerConfig`, `WalletSession` and the individual
`callService`, `inspectService`, `searchMarketplace` and `getWallet` tools.

## Interactive results in Claude Desktop

`call.search` and `call.inspect` show marketplace results and listing details as interactive MCP Apps in Claude Desktop.
The deprecated `search` and `inspect` aliases use the same views.

On `initialize`, the server fetches each view's HTML from `<registry origin>/mcp/apps/<view>.html` with a 2-second timeout.
Successfully fetched HTML is cached in memory for the process.
The default origin is `https://api.vapinetwork.ai` and follows the configured registry.

The server needs network access to that route; if loading fails, initialization still succeeds and tools return their normal text results.
It exposes the views as `ui://vapi/call-search.html` and `ui://vapi/call-inspect.html` through `resources/list` and `resources/read`.

## Exports

These tables show selected exports. [src/index.ts](https://github.com/vAPI-Network/vapi-network/blob/main/packages/mcp/src/index.ts) defines the full entry point. The [tool reference](https://github.com/vAPI-Network/vapi-network/blob/main/docs/mcp.md#tools) lists every registered MCP tool.

### Selected runtime exports

| Name                     | What it is                                                                                                                                                                                                                                                           | Since            |
| ------------------------ | -------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- | ---------------- |
| `buildSIWxProof`         | function (args: { signer: SIWxSigner; challenge: SIWxChallenge; responseUrl: string; }): unknown                                                                                                                                                                     | 0.5.0 or earlier |
| `callService`            | function (args: CallServiceArgs): Promise<CallToolResult>                                                                                                                                                                                                            | 0.5.0 or earlier |
| `callRead`               | action `call.read`: GET an HTTPS URL from an origin paid in the current agent run; SIWX sign-in is allowed, but it never pays                                                                                                                                        | 0.8.0            |
| `createAgentRunDeps`     | function (input: { profile: AgentProfile; config: VapiConfig; home: string; account: VapiPaymentAccount; wallet: WalletName; spendCaps: SpendCaps; chat: (req: ChatRequest) => Promise<ChatResult>; approve: RunAgentDeps["approve"]; onEvent?: (event: AgentEven... | 0.5.0 or earlier |
| `createVapiServer`       | function (options?: VapiServerOptions): unknown; without account/config it registers the wallet-free docs tools only                                                                                                                                                 | 0.5.0 or earlier |
| `decidePayment`          | function (input: { ref: string; priceUsd: number \| null; verification: string; seenRefs: ReadonlySet<string>; verifiedOnly: boolean; approveAboveUsd: number; maxPerCallUsd: number; }): PayDecision                                                                | 0.5.0 or earlier |
| `getWallet`              | function (account: Address \| WalletAddresses \| VapiPaymentAccount, config: VapiConfig, options: { fetchImpl?: typeof fetch; lookup?: LookupFn } = {}): Promise<{ address: Address; balances: WalletBalance[] }>                                                    | 0.5.0 or earlier |
| `inspectService`         | function (input: InspectToolInput, config: VapiConfig, fetchImpl?: typeof fetch): Promise<InspectToolResult>                                                                                                                                                         | 0.5.0 or earlier |
| `loadServerConfig`       | function (): unknown                                                                                                                                                                                                                                                 | 0.5.0 or earlier |
| `parseSIWxResponse`      | function (response: Response, configuredNetworks: VapiConfig["networks"], responseUrl: string, requiredNetwork?: string): Promise<SIWxChallenge \| null>                                                                                                             | 0.5.0 or earlier |
| `readPaidOrigin`         | function (args: { url; paidOrigins; account; config; fetchImpl?; lookup?; timeoutMs? }): Promise<CallReadOutput>                                                                                                                                                     | 0.8.0            |
| `resolveServiceEndpoint` | function (id: string, config: VapiRegistryConfig, fetchImpl?: Fetch, endpointName?: string): Promise<DiscoveryEndpoint>                                                                                                                                              | 0.5.0 or earlier |
| `resolveServiceListing`  | function (id: string, config: VapiRegistryConfig, fetchImpl?: Fetch, endpointName?: string): Promise<ResolvedListing>                                                                                                                                                | 0.5.0 or earlier |
| `runAgent`               | function (task: string, deps: RunAgentDeps): Promise<RunAgentResult>                                                                                                                                                                                                 | 0.5.0 or earlier |
| `searchMarketplace`      | function (input: MarketplaceSearchInput, config: VapiRegistryConfig, fetchImpl?: Fetch, options?: MarketplaceSearchOptions): Promise<MarketplaceDiscoveryPage>                                                                                                       | 0.5.0 or earlier |
| `startStdioServer`       | function (options: VapiServerOptions): unknown                                                                                                                                                                                                                       | 0.5.0 or earlier |
| `UNTRUSTED_NOTICE`       | constant UNTRUSTED_NOTICE: string                                                                                                                                                                                                                                    | 0.5.0 or earlier |
| `WalletSession`          | class WalletSession                                                                                                                                                                                                                                                  | 0.5.0 or earlier |
| `wrapUntrusted`          | function (tool: string, value: unknown): string                                                                                                                                                                                                                      | 0.5.0 or earlier |

### Selected types

| Name                     | What it is                                                                                                                                                                                                                                                                                             | Since            |
| ------------------------ | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ---------------- |
| `AgentEvent`             | type AgentEvent = \| { type: "step"; n: number } \| { type: "tool"; name: string; summary: string } \| { type: "paid"; ref: string; amountUsd: number; network: string } \| { type: "declined"; ref: string; reason: string } \| { type: "stopped"; reason: "finished"...                              | 0.5.0 or earlier |
| `CallToolInput`          | type CallToolInput = { id?: string; url?: string; method?: string; endpoint?: string; body?: unknown; maxPriceUsd?: number \| string; network?: string; expectedPayTo?: string; contentType?: string; timeoutSeconds?: number; }                                                                       | 0.5.0 or earlier |
| `CallToolResult`         | type CallToolResult = { status: number; body: unknown; verification?: ListingVerification; outcome?: "signed_in"; payment: null \| { network: string; amountAtomic: string; amountUsd: string; asset: string; payTo: string; settlement: unknown \| null; proof: st...                                 | 0.5.0 or earlier |
| `CallReadInput`          | type CallReadInput = { url: string }                                                                                                                                                                                                                                                                   | 0.8.0            |
| `CallReadOutput`         | type CallReadOutput = { status: number; contentType: string \| null; body: unknown }                                                                                                                                                                                                                   | 0.8.0            |
| `InspectToolInput`       | type InspectToolInput = { id: string; endpoint?: string; }                                                                                                                                                                                                                                             | 0.5.0 or earlier |
| `InspectToolResult`      | type InspectToolResult = Omit<Pick<DiscoveryEndpoint, ...>, "method"> & { method: string \| null; health?: ListingHealth; ... }; includes optional responseSchema and exampleRequest                                                                                                                   | 0.5.0 or earlier |
| `MarketplaceSearchInput` | type MarketplaceSearchInput = { query?: string; kinds?: MarketplaceKind[]; network?: string; limit?: number; cursor?: string; includeUnverified?: boolean; includeOutage?: boolean; }                                                                                                                  | 0.5.0 or earlier |
| `PayDecision`            | type PayDecision = { action: "pay" } \| { action: "ask"; reason: string } \| { action: "refuse"; reason: string }                                                                                                                                                                                      | 0.5.0 or earlier |
| `RunAgentDeps`           | type RunAgentDeps = { profile: AgentProfile; config: VapiConfig; home: string; chat: (req: ChatRequest) => Promise<ChatResult>; search: (q: { query: string; network?: string; includeUnverified: boolean }) => Promise< Array<{ ref: string; name: string; price...                                   | 0.5.0 or earlier |
| `RunAgentResult`         | type RunAgentResult = { answer: string \| null; stoppedBecause: AgentEvent & { type: "stopped" }; paidUsd: number; steps: number; }                                                                                                                                                                    | 0.5.0 or earlier |
| `SessionWallet`          | type SessionWallet = { name: WalletName; path?: string; }                                                                                                                                                                                                                                              | 0.5.0 or earlier |
| `SessionWalletInfo`      | type SessionWalletInfo = { name: WalletName; address?: string; solanaAddress?: string; label?: string; isDefault: boolean; isActive: boolean; spendCaps?: SpendCaps; }                                                                                                                                 | 0.5.0 or earlier |
| `VapiServerOptions`      | type VapiServerOptions = { account?: VapiPaymentAccount; config?: VapiConfig; fetchImpl?: typeof fetch; ledgerPath?: string; receiptsPath?: string; searchesPath?: string; reportsDirectory?: string; store?: WalletStore \| undefined; wallet?: string \| undefined; status?: StatusCoreOverrides;... | 0.5.0 or earlier |
| `WalletAddresses`        | type WalletAddresses = { address: Address; solana?: { address: string } \| undefined; }                                                                                                                                                                                                                | 0.5.0 or earlier |
| `WalletBalance`          | type WalletBalance = { network: string; name: string; usdcAtomic: string \| null; usdc: string \| null; error?: string; }                                                                                                                                                                              | 0.5.0 or earlier |
| `WalletSessionOptions`   | type WalletSessionOptions = { account: VapiPaymentAccount; store?: WalletStore \| undefined; wallet?: string \| undefined; env?: NodeJS.ProcessEnv \| undefined; passphrase?: (() => string \| Promise<string>) \| undefined; secretStore?: SecretStore \| undefined; n...                             | 0.5.0 or earlier |

See the [root README](https://github.com/vAPI-Network/vapi-network/blob/main/docs/mcp.md) for the editor configuration, the full tool table and the deprecated aliases.

`call.read` is available to agent runs with the `read` grant. It only sends
GET requests to HTTPS origins that the same agent paid in the current run,
follows guarded redirects, and never makes another payment. A 402 may be
retried once with a SIWX sign-in proof bound to that origin. The MCP surface
lists the tool for schema alignment, but calls outside an agent run are refused.
