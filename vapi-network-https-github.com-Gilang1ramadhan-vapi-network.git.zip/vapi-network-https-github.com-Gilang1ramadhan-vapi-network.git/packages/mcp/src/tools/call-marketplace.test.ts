import { mkdtemp, readFile, rm } from "node:fs/promises";
import { tmpdir } from "node:os";
import { join } from "node:path";

import { afterEach, describe, expect, it, vi } from "vitest";
import { getAddress, type Hex } from "viem";
import { privateKeyToAccount } from "viem/accounts";

import {
  BASE_MAINNET_CAIP2,
  SOLANA_MAINNET_CAIP2,
  SOLANA_MAINNET_USDC,
  X402_SOLANA_MAINNET_CAIP2,
  createKeystore,
  getDefaultConfig,
  readReceipts,
} from "@vapi-network/core";

import { VapiCallError, callService } from "./call.js";

const PRIVATE_KEY = "0x0123456789abcdef0123456789abcdef0123456789abcdef0123456789abcdef" as Hex;
const PAY_TO = getAddress("0x1111111111111111111111111111111111111111");
const OTHER_PAYEE = getAddress("0x2222222222222222222222222222222222222222");
const TOKEN_PROGRAM_ADDRESS = "TokenkegQfeZyiNwAJbNbGKPFXCWuBvf9Ss623VQ5DA";
const temporaryDirectories: string[] = [];

afterEach(async () => {
  vi.useRealTimers();
  await Promise.all(
    temporaryDirectories.splice(0).map((directory) => rm(directory, { recursive: true })),
  );
});

describe("Agent Cash marketplace call boundary", () => {
  it.each([
    { offerSeconds: 10, expectedSeconds: 30 },
    { offerSeconds: 300, expectedSeconds: 120 },
    { offerSeconds: 10, timeoutSeconds: 25, expectedSeconds: 10 },
    { offerSeconds: 300, timeoutSeconds: 45, internalTimeoutMs: 100, expectedSeconds: 45 },
  ])(
    "times out a paid response after $expectedSeconds seconds for offer $offerSeconds",
    async ({ offerSeconds, timeoutSeconds, internalTimeoutMs, expectedSeconds }) => {
      vi.useFakeTimers();
      const directory = await mkdtemp(join(tmpdir(), "vapi-paid-timeout-"));
      temporaryDirectories.push(directory);
      let markPaidRequestStarted!: () => void;
      const paidRequestStarted = new Promise<void>((resolve) => {
        markPaidRequestStarted = resolve;
      });
      const fetchImpl = vi
        .fn<typeof fetch>()
        .mockResolvedValueOnce(paymentRequired(PAY_TO, offerSeconds))
        .mockImplementationOnce(async (input) => {
          markPaidRequestStarted();
          return await abortedFetch(input);
        });

      const call = callService({
        input: {
          url: "https://93.184.216.34/weather",
          method: "GET",
          maxPriceUsd: "0.01",
          ...(timeoutSeconds === undefined ? {} : { timeoutSeconds }),
        },
        account: privateKeyToAccount(PRIVATE_KEY),
        config: getDefaultConfig(),
        fetchImpl,
        ledgerPath: join(directory, "ledger.json"),
        receiptsPath: join(directory, "receipts.jsonl"),
        ...(internalTimeoutMs === undefined ? {} : { timeoutMs: internalTimeoutMs }),
      });
      let rejected = false;
      const earlyCompletion = call.then(
        () => {
          throw new Error("Paid call resolved before its request started.");
        },
        (error: unknown) => {
          rejected = true;
          throw error;
        },
      );
      await Promise.race([paidRequestStarted, earlyCompletion]);
      expect(fetchImpl).toHaveBeenCalledTimes(2);
      await vi.advanceTimersByTimeAsync(expectedSeconds * 1_000 - 1);
      expect(rejected).toBe(false);
      await vi.advanceTimersByTimeAsync(1);
      await expect(call).rejects.toMatchObject({
        code: "settlement_unknown",
        message: expect.stringMatching(
          new RegExp(`${expectedSeconds} seconds.*before paying again`, "s"),
        ),
      });
    },
  );

  it.each([
    { expectedSeconds: 30 },
    { timeoutSeconds: 5, expectedSeconds: 5 },
    { timeoutSeconds: 45, expectedSeconds: 30 },
  ])(
    "times out the unpaid probe after $expectedSeconds seconds",
    async ({ timeoutSeconds, expectedSeconds }) => {
      vi.useFakeTimers();
      const fetchImpl = vi.fn<typeof fetch>(async (input) => await abortedFetch(input));
      const call = callService({
        input: {
          url: "https://93.184.216.34/weather",
          method: "GET",
          ...(timeoutSeconds === undefined ? {} : { timeoutSeconds }),
        },
        account: privateKeyToAccount(PRIVATE_KEY),
        config: getDefaultConfig(),
        fetchImpl,
      });
      await vi.advanceTimersByTimeAsync(expectedSeconds * 1_000 - 1);
      let rejected = false;
      void call.catch(() => {
        rejected = true;
      });
      expect(rejected).toBe(false);
      await vi.advanceTimersByTimeAsync(1);
      await expect(call).rejects.toThrow(`${expectedSeconds} seconds`);
    },
  );

  it.each([0, 1.5, 301])("rejects invalid timeoutSeconds %s before I/O", async (timeoutSeconds) => {
    const fetchImpl = vi.fn<typeof fetch>();
    await expect(
      callService({
        input: { url: "https://93.184.216.34/weather", timeoutSeconds },
        account: privateKeyToAccount(PRIVATE_KEY),
        config: getDefaultConfig(),
        fetchImpl,
      }),
    ).rejects.toThrow("integer from 1 to 300 seconds");
    expect(fetchImpl).not.toHaveBeenCalled();
  });

  it.each(["mpp", "future-payment"])(
    "refuses %s metadata before requesting or signing",
    async (protocol) => {
      const directory = await mkdtemp(join(tmpdir(), "vapi-unsupported-payment-"));
      temporaryDirectories.push(directory);
      const account = privateKeyToAccount(PRIVATE_KEY);
      const sign = vi.spyOn(account, "signTypedData");
      const fetchImpl = vi.fn<typeof fetch>().mockResolvedValueOnce(
        Response.json({
          services: [
            service({
              endpoints: [
                endpoint({
                  payment: {
                    protocol,
                    intent: "charge",
                    method: "tempo",
                    checkedAt: "2026-10-15T12:00:00.000Z",
                  },
                }),
              ],
            }),
          ],
        }),
      );
      await expect(
        callService({
          input: { id: "imported-weather" },
          account,
          config: getDefaultConfig(),
          fetchImpl,
          ledgerPath: join(directory, "spend-ledger.json"),
        }),
      ).rejects.toMatchObject({
        code: "unsupported_payment",
        message: expect.stringContaining(`Payment protocol ${protocol} is not supported`),
      });
      expect(fetchImpl).toHaveBeenCalledOnce();
      expect(sign).not.toHaveBeenCalled();
      await expect(readFile(join(directory, "spend-ledger.json"))).rejects.toMatchObject({
        code: "ENOENT",
      });
    },
  );

  it("rejects a Work result before making a network request", async () => {
    const fetchImpl = vi.fn<typeof fetch>();

    await expect(
      callService({
        input: { id: "research-brief" },
        marketplaceHit: {
          ref: "research-brief",
          kind: "service_offer",
          verification: "none" as const,
          card: {
            title: "Research brief",
            summary: "Evidence-backed market research.",
            badges: [],
            facts: [],
          },
          action: { type: "start_engagement", href: "/work/listings/research-brief" },
        },
        account: privateKeyToAccount(PRIVATE_KEY),
        config: getDefaultConfig(),
        fetchImpl,
      }),
    ).rejects.toThrow("only invokes API marketplace results");
    expect(fetchImpl).not.toHaveBeenCalled();
  });

  it("invokes an external-catalog API from structured execution metadata only", async () => {
    const fetchImpl = vi
      .fn<typeof fetch>()
      .mockResolvedValue(new Response(JSON.stringify({ ok: true }), { status: 200 }));

    const result = await callService({
      input: { id: "https://93.184.216.34/weather", method: "POST" },
      marketplaceHit: {
        ref: "https://93.184.216.34/weather",
        kind: "api",
        provenance: "indexed",
        verification: "none" as const,
        execution: {
          mode: "direct",
          url: "https://93.184.216.34/weather",
          method: "POST",
          network: BASE_MAINNET_CAIP2,
        },
        card: {
          title: "External weather API",
          summary: "Weather from the x402 catalog.",
          badges: [{ code: "external_catalog", label: "External catalog" }],
          facts: [{ label: "Method", value: "DELETE" }],
        },
        action: {
          type: "invoke_api",
          href: "/call/invoke?url=https%3A%2F%2F93.184.216.35%2Fwrong&method=DELETE",
        },
      },
      account: privateKeyToAccount(PRIVATE_KEY),
      config: getDefaultConfig(),
      fetchImpl,
    });

    expect(result).toEqual({
      status: 200,
      body: { ok: true },
      verification: "none",
      payment: null,
    });
    expect(fetchImpl).toHaveBeenCalledOnce();
    const request = fetchImpl.mock.calls[0]![0] as Request;
    expect(request.url).toBe("https://93.184.216.34/weather");
    expect(request.method).toBe("POST");
  });

  it("rejects an initial HTTP API URL before sending a request body", async () => {
    const fetchImpl = vi.fn<typeof fetch>();

    await expect(
      callService({
        input: {
          url: "http://93.184.216.34/weather",
          method: "POST",
          body: { city: "Amsterdam" },
        },
        account: privateKeyToAccount(PRIVATE_KEY),
        config: getDefaultConfig(),
        fetchImpl,
      }),
    ).rejects.toThrow(/HTTPS/);
    expect(fetchImpl).not.toHaveBeenCalled();
  });

  it("rejects an HTTPS-to-HTTP redirect without forwarding a request body", async () => {
    const fetchImpl = vi
      .fn<typeof fetch>()
      .mockResolvedValueOnce(
        new Response(null, {
          status: 307,
          headers: { location: "http://93.184.216.34/redirected" },
        }),
      )
      .mockResolvedValueOnce(Response.json({ shouldNotBeReached: true }));

    await expect(
      callService({
        input: {
          url: "https://93.184.216.34/weather",
          method: "POST",
          body: { city: "Amsterdam" },
        },
        account: privateKeyToAccount(PRIVATE_KEY),
        config: getDefaultConfig(),
        fetchImpl,
      }),
    ).rejects.toThrow(/HTTPS/);
    expect(fetchImpl).toHaveBeenCalledOnce();
  });

  it("allows an HTTP localhost development target only with the private-network opt-in", async () => {
    const config = getDefaultConfig();
    config.allowPrivateNetwork = true;
    const fetchImpl = vi.fn<typeof fetch>().mockResolvedValueOnce(Response.json({ local: true }));

    const result = await callService({
      input: { url: "http://localhost:5173/weather", method: "GET" },
      account: privateKeyToAccount(PRIVATE_KEY),
      config,
      fetchImpl,
    });

    expect(result).toMatchObject({ status: 200, body: { local: true } });
    expect(fetchImpl).toHaveBeenCalledOnce();
  });

  it.each([
    { status: 301, method: "POST", expectedMethod: "GET", preservesBody: false },
    { status: 301, method: "PUT", expectedMethod: "PUT", preservesBody: true },
    { status: 302, method: "POST", expectedMethod: "GET", preservesBody: false },
    { status: 302, method: "PUT", expectedMethod: "PUT", preservesBody: true },
    { status: 303, method: "POST", expectedMethod: "GET", preservesBody: false },
    { status: 303, method: "PUT", expectedMethod: "GET", preservesBody: false },
    { status: 307, method: "POST", expectedMethod: "POST", preservesBody: true },
    { status: 307, method: "PUT", expectedMethod: "PUT", preservesBody: true },
    { status: 308, method: "POST", expectedMethod: "POST", preservesBody: true },
    { status: 308, method: "PUT", expectedMethod: "PUT", preservesBody: true },
  ])(
    "follows HTTP $status for $method as $expectedMethod with Fetch body semantics",
    async ({ status, method, expectedMethod, preservesBody }) => {
      const fetchImpl = vi
        .fn<typeof fetch>()
        .mockResolvedValueOnce(
          new Response(null, {
            status,
            headers: { location: "https://93.184.216.34/redirected" },
          }),
        )
        .mockResolvedValueOnce(Response.json({ ok: true }));

      await callService({
        input: {
          url: "https://93.184.216.34/weather",
          method,
          body: { city: "Amsterdam" },
        },
        account: privateKeyToAccount(PRIVATE_KEY),
        config: getDefaultConfig(),
        fetchImpl,
      });

      const redirected = fetchImpl.mock.calls[1]![0] as Request;
      expect(redirected.url).toBe("https://93.184.216.34/redirected");
      expect(redirected.method).toBe(expectedMethod);
      expect(redirected.headers.get("content-type")).toBe(
        preservesBody ? "application/json" : null,
      );
      await expect(redirected.text()).resolves.toBe(
        preservesBody ? JSON.stringify({ city: "Amsterdam" }) : "",
      );
    },
  );

  it("rejects a method that conflicts with the external catalog action", async () => {
    const fetchImpl = vi.fn<typeof fetch>();

    await expect(
      callService({
        input: { id: "https://93.184.216.34/weather", method: "DELETE" },
        marketplaceHit: {
          ref: "https://93.184.216.34/weather",
          kind: "api",
          provenance: "indexed",
          verification: "none" as const,
          execution: {
            mode: "direct",
            url: "https://93.184.216.34/weather",
            method: "GET",
            network: BASE_MAINNET_CAIP2,
          },
          card: {
            title: "External weather API",
            summary: "Weather from the x402 catalog.",
            badges: [{ code: "external_catalog", label: "External catalog" }],
            facts: [{ label: "Method", value: "GET" }],
          },
          action: {
            type: "invoke_api",
            href: "/call/invoke?url=https%3A%2F%2F93.184.216.34%2Fweather&method=GET",
          },
        },
        account: privateKeyToAccount(PRIVATE_KEY),
        config: getDefaultConfig(),
        fetchImpl,
        lookup: async () => ["93.184.216.34"],
      }),
    ).rejects.toThrow(/conflicting method override/);
    expect(fetchImpl).not.toHaveBeenCalled();
  });

  it("rejects an external network override that conflicts with execution metadata", async () => {
    const fetchImpl = vi.fn<typeof fetch>();
    const config = getDefaultConfig({ ARC_TESTNET_RPC_URL: "https://arc-rpc.example" });

    await expect(
      callService({
        input: {
          id: "https://93.184.216.34/weather",
          method: "GET",
          network: "eip155:5042002",
        },
        marketplaceHit: {
          ref: "https://93.184.216.34/weather",
          kind: "api",
          provenance: "indexed",
          verification: "none" as const,
          execution: {
            mode: "direct",
            url: "https://93.184.216.34/weather",
            method: "GET",
            network: BASE_MAINNET_CAIP2,
          },
          card: {
            title: "External weather API",
            summary: "Weather from the x402 catalog.",
            badges: [{ code: "external_catalog", label: "External catalog" }],
            facts: [],
          },
          action: { type: "invoke_api", href: "/call/invoke" },
        },
        account: privateKeyToAccount(PRIVATE_KEY),
        config,
        fetchImpl,
      }),
    ).rejects.toThrow(/requires eip155:8453.*requested network was eip155:5042002/);
    expect(fetchImpl).not.toHaveBeenCalled();
  });

  it("refuses a cached Solana marketplace hit before requesting or signing", async () => {
    const directory = await mkdtemp(join(tmpdir(), "vapi-mcp-solana-marketplace-"));
    temporaryDirectories.push(directory);
    const ledgerPath = join(directory, "ledger.json");
    const receiptsPath = join(directory, "receipts.jsonl");
    const account = privateKeyToAccount(PRIVATE_KEY);
    const signTypedData = vi.spyOn(account, "signTypedData");
    const signMessage = vi.spyOn(account, "signMessage");
    const fetchImpl = vi.fn<typeof fetch>();

    const error = await callService({
      input: { id: "https://api.deepnets.ai/api/token/holder-graph" },
      marketplaceHit: {
        ref: "https://api.deepnets.ai/api/token/holder-graph",
        kind: "api",
        provenance: "indexed",
        verification: "none",
        execution: {
          mode: "direct",
          url: "https://api.deepnets.ai/api/token/holder-graph",
          method: "GET",
          network: "solana:5eykt4UsFv8P8NJdTREpY1vzqKqZKvdp",
        },
        card: {
          title: "DeepNets holder graph",
          summary: "Funding-source graph for a token.",
          badges: [{ code: "external_catalog", label: "External catalog" }],
          facts: [],
        },
        action: {
          type: "invoke_api",
          href: "https://api.deepnets.ai/api/token/holder-graph",
        },
      },
      account,
      config: getDefaultConfig(),
      fetchImpl,
      ledgerPath,
      receiptsPath,
    }).catch((caught: unknown) => caught);

    expect(error).toBeInstanceOf(VapiCallError);
    expect(error).toMatchObject({ code: "unsupported_network" });
    expect((error as Error).message).not.toContain("ZodError");
    expect(fetchImpl).not.toHaveBeenCalled();
    expect(signTypedData).not.toHaveBeenCalled();
    expect(signMessage).not.toHaveBeenCalled();
    await expect(readReceipts(receiptsPath)).resolves.toEqual([]);
  });

  it("refuses a services-API mirror whose declared networks are all Solana", async () => {
    // Production resolves a mirrored URL ref through /services as a service with
    // `networks: ["solana:…"]` and an endpoint without payment metadata.
    const fixture = JSON.parse(
      await readFile(
        new URL(
          "../../../sources/src/__fixtures__/vapi-services-deepnets-solana.json",
          import.meta.url,
        ),
        "utf8",
      ),
    ) as unknown;
    const targetUrl = "https://api.deepnets.ai/api/token/holder-graph";
    const account = privateKeyToAccount(PRIVATE_KEY);
    const signTypedData = vi.spyOn(account, "signTypedData");
    const fetchImpl = vi.fn<typeof fetch>(async (input) => {
      const url = new URL(input instanceof Request ? input.url : String(input));
      if (url.pathname.endsWith("/services")) return Response.json(fixture);
      throw new Error(`Unexpected request to ${url.href}`);
    });

    const error = await callService({
      input: { id: targetUrl },
      account,
      config: getDefaultConfig(),
      fetchImpl,
    }).catch((caught: unknown) => caught);

    expect(error).toMatchObject({ code: "unsupported_network" });
    expect(
      fetchImpl.mock.calls.some(([input]) =>
        (input instanceof Request ? input.url : String(input)).startsWith(targetUrl),
      ),
    ).toBe(false);
    expect(signTypedData).not.toHaveBeenCalled();
  });

  it("never selects a Solana quote for an account without a Solana signer", async () => {
    const directory = await mkdtemp(join(tmpdir(), "vapi-mcp-solana-no-signer-"));
    temporaryDirectories.push(directory);
    const ledgerPath = join(directory, "ledger.json");
    const config = getDefaultConfig({}, { networks: ["base", "solana"] });
    config.networks[SOLANA_MAINNET_CAIP2]!.rpcUrl = "https://rpc.example";
    const fetchImpl = vi.fn<typeof fetch>(async () => solanaPaymentRequired());

    await expect(
      callService({
        input: { url: "https://93.184.216.34/weather", method: "GET" },
        account: privateKeyToAccount(PRIVATE_KEY),
        config,
        fetchImpl,
        ledgerPath,
        receiptsPath: join(directory, "receipts.jsonl"),
      }),
    ).rejects.toThrow(/No exact x402 payment option matches/);
    // Quote selection failed, so no spend was reserved for a payment that could not be signed.
    await expect(readFile(ledgerPath, "utf8")).rejects.toMatchObject({ code: "ENOENT" });
  });

  it("requires an explicit method when external execution metadata publishes null", async () => {
    const fetchImpl = vi.fn<typeof fetch>();

    await expect(
      callService({
        input: { id: "https://93.184.216.34/weather" },
        marketplaceHit: {
          ref: "https://93.184.216.34/weather",
          kind: "api",
          provenance: "indexed",
          verification: "none" as const,
          execution: {
            mode: "direct",
            url: "https://93.184.216.34/weather",
            method: null,
            network: BASE_MAINNET_CAIP2,
          },
          card: {
            title: "External weather API",
            summary: "Weather from the x402 catalog.",
            badges: [{ code: "external_catalog", label: "External catalog" }],
            facts: [],
          },
          action: { type: "invoke_api", href: "/call/invoke" },
        },
        account: privateKeyToAccount(PRIVATE_KEY),
        config: getDefaultConfig(),
        fetchImpl,
      }),
    ).rejects.toThrow(/require an explicit method/);
    expect(fetchImpl).not.toHaveBeenCalled();
  });

  it("rejects unsupported explicit HTTP methods", async () => {
    const fetchImpl = vi.fn<typeof fetch>();

    await expect(
      callService({
        input: { url: "https://93.184.216.34/weather", method: "TRACE" },
        account: privateKeyToAccount(PRIVATE_KEY),
        config: getDefaultConfig(),
        fetchImpl,
      }),
    ).rejects.toThrow(/method must be one of/);
    expect(fetchImpl).not.toHaveBeenCalled();
  });

  it("resolves a native vAPI id through the Calls compatibility contract", async () => {
    const fetchImpl = vi
      .fn<typeof fetch>()
      .mockResolvedValueOnce(Response.json({ services: [service()] }))
      .mockResolvedValueOnce(Response.json({ imported: true }));

    const result = await callService({
      input: { id: "imported-weather" },
      marketplaceHit: apiHit({
        ref: "imported-weather",
        href: "/call/imported-weather",
      }),
      account: privateKeyToAccount(PRIVATE_KEY),
      config: getDefaultConfig(),
      fetchImpl,
      lookup: async () => ["93.184.216.34"],
    });

    expect(result).toMatchObject({ status: 200, body: { imported: true } });
    expect((fetchImpl.mock.calls[1]![0] as Request).url).toBe("https://93.184.216.34/weather");
  });

  it("rejects a missing top-level required key before calling or signing for the endpoint", async () => {
    const requestSchema = {
      type: "object",
      required: ["authorization", "network"],
      properties: {
        authorization: { type: "string" },
        network: { type: "string" },
      },
    };
    const account = privateKeyToAccount(PRIVATE_KEY);
    const signSpy = vi.spyOn(account, "signTypedData");
    const fetchImpl = vi.fn<typeof fetch>().mockResolvedValueOnce(
      Response.json({
        services: [
          service({
            endpoints: [endpoint({ requestContentType: "application/json", requestSchema })],
          }),
        ],
      }),
    );

    const error = await callService({
      input: {
        id: "imported-weather",
        body: { authorization: "signed-payload" },
      },
      marketplaceHit: apiHit({ ref: "imported-weather" }),
      account,
      config: getDefaultConfig(),
      fetchImpl,
      lookup: async () => ["93.184.216.34"],
    }).catch((caught: unknown) => caught);

    expect(error).toBeInstanceOf(VapiCallError);
    expect(error).toMatchObject({ code: "invalid_request" });
    expect((error as Error).message).toContain('missing required keys: "network"');
    expect((error as Error).message).toContain(JSON.stringify(requestSchema));
    expect((error as Error).message).toContain("application/json");
    expect(fetchImpl).toHaveBeenCalledOnce();
    expect(new URL(fetchImpl.mock.calls[0]![0] as URL).pathname).toBe("/api/call/services");
    expect(signSpy).not.toHaveBeenCalled();
  });

  it("calls through when the body contains every top-level required key", async () => {
    const fetchImpl = vi
      .fn<typeof fetch>()
      .mockResolvedValueOnce(
        Response.json({
          services: [
            service({
              endpoints: [
                endpoint({
                  requestContentType: "application/json",
                  requestSchema: {
                    type: "object",
                    required: ["authorization", "network"],
                  },
                }),
              ],
            }),
          ],
        }),
      )
      .mockResolvedValueOnce(Response.json({ decoded: true }));

    const result = await callService({
      input: {
        id: "imported-weather",
        body: { authorization: "signed-payload", network: "eip155:8453" },
      },
      marketplaceHit: apiHit({ ref: "imported-weather" }),
      account: privateKeyToAccount(PRIVATE_KEY),
      config: getDefaultConfig(),
      fetchImpl,
      lookup: async () => ["93.184.216.34"],
    });

    expect(result).toEqual({
      status: 200,
      body: { decoded: true },
      verification: "none",
      payment: null,
    });
    expect(fetchImpl).toHaveBeenCalledTimes(2);
    const request = fetchImpl.mock.calls[1]![0] as Request;
    await expect(request.json()).resolves.toEqual({
      authorization: "signed-payload",
      network: "eip155:8453",
    });
  });

  it("echoes the resolved listing's expected request contract on an HTTP 400", async () => {
    const requestSchema = {
      type: "object",
      required: ["authorization"],
      properties: { authorization: { type: "string" } },
    };
    const fetchImpl = vi
      .fn<typeof fetch>()
      .mockResolvedValueOnce(
        Response.json({
          services: [
            service({
              endpoints: [endpoint({ requestContentType: "application/json", requestSchema })],
            }),
          ],
        }),
      )
      .mockResolvedValueOnce(
        Response.json({ error: "authorization was malformed" }, { status: 400 }),
      );

    const result = await callService({
      input: {
        id: "imported-weather",
        body: { authorization: "malformed-payload" },
      },
      marketplaceHit: apiHit({ ref: "imported-weather" }),
      account: privateKeyToAccount(PRIVATE_KEY),
      config: getDefaultConfig(),
      fetchImpl,
      lookup: async () => ["93.184.216.34"],
    });

    expect(result).toEqual({
      status: 400,
      body: { error: "authorization was malformed" },
      verification: "none",
      payment: null,
      expectedRequest: {
        contentType: "application/json",
        schema: requestSchema,
      },
    });
  });

  it("binds a registered API call to its confirmed payee before signing", async () => {
    const account = privateKeyToAccount(PRIVATE_KEY);
    const signSpy = vi.spyOn(account, "signTypedData");
    const fetchImpl = vi
      .fn<typeof fetch>()
      .mockResolvedValueOnce(Response.json({ services: [service()] }))
      .mockResolvedValueOnce(paymentRequired(OTHER_PAYEE));

    await expect(
      callService({
        input: { id: "imported-weather" },
        marketplaceHit: apiHit({ ref: "imported-weather" }),
        account,
        config: getDefaultConfig(),
        fetchImpl,
        lookup: async () => ["93.184.216.34"],
      }),
    ).rejects.toThrow(/No exact x402 payment option matches/);
    expect(signSpy).not.toHaveBeenCalled();
    expect(fetchImpl).toHaveBeenCalledTimes(2);
  });

  it("rejects a network or method override that conflicts with the registered endpoint", async () => {
    for (const input of [
      { id: "imported-weather", network: "eip155:5042002" },
      { id: "imported-weather", method: "GET" },
    ]) {
      const fetchImpl = vi
        .fn<typeof fetch>()
        .mockResolvedValueOnce(Response.json({ services: [service()] }));
      await expect(
        callService({
          input,
          marketplaceHit: apiHit({ ref: "imported-weather" }),
          account: privateKeyToAccount(PRIVATE_KEY),
          config: getDefaultConfig(),
          fetchImpl,
        }),
      ).rejects.toThrow(/registered endpoint|not configured/);
      expect(fetchImpl).toHaveBeenCalledOnce();
    }
  });

  it("pays once when the live quote matches the registered network and payee", async () => {
    const directory = await mkdtemp(join(tmpdir(), "vapi-mcp-marketplace-call-"));
    temporaryDirectories.push(directory);
    const fetchImpl = vi
      .fn<typeof fetch>()
      .mockResolvedValueOnce(Response.json({ services: [service()] }))
      .mockResolvedValueOnce(paymentRequired(PAY_TO))
      .mockResolvedValueOnce(Response.json({ paid: true }));

    const result = await callService({
      input: { id: "imported-weather", maxPriceUsd: "0.01" },
      marketplaceHit: apiHit({ ref: "imported-weather" }),
      account: privateKeyToAccount(PRIVATE_KEY),
      config: getDefaultConfig(),
      fetchImpl,
      lookup: async () => ["93.184.216.34"],
      ledgerPath: join(directory, "ledger.json"),
    });

    expect(result).toMatchObject({
      body: { paid: true },
      payment: { network: BASE_MAINNET_CAIP2, payTo: PAY_TO },
    });
    expect(fetchImpl).toHaveBeenCalledTimes(3);
    expect((fetchImpl.mock.calls[2]![0] as Request).headers.has("payment-signature")).toBe(true);
  });

  it("signs in to an auth-only SIWX server and records a zero-amount receipt", async () => {
    const directory = await mkdtemp(join(tmpdir(), "vapi-mcp-siwx-"));
    temporaryDirectories.push(directory);
    const account = privateKeyToAccount(PRIVATE_KEY);
    const signMessage = vi.spyOn(account, "signMessage");
    const fetchImpl = vi
      .fn<typeof fetch>()
      .mockResolvedValueOnce(Response.json(signInRequired(), { status: 402 }))
      .mockResolvedValueOnce(Response.json({ private: true }));
    const receiptsPath = join(directory, "receipts.jsonl");

    const result = await callService({
      input: { url: "https://93.184.216.34/weather", method: "GET" },
      account,
      config: getDefaultConfig(),
      fetchImpl,
      receiptsPath,
    });

    expect(result).toEqual({
      status: 200,
      body: { private: true },
      payment: null,
      outcome: "signed_in",
    });
    expect(signMessage).toHaveBeenCalledOnce();
    const signedRequest = fetchImpl.mock.calls[1]![0] as Request;
    const proof = JSON.parse(
      Buffer.from(signedRequest.headers.get("sign-in-with-x")!, "base64").toString("utf8"),
    ) as Record<string, unknown>;
    expect(proof).toMatchObject({
      domain: "93.184.216.34",
      uri: "https://93.184.216.34/weather",
      chainId: BASE_MAINNET_CAIP2,
      type: "eip191",
      address: account.address,
    });
    await expect(readReceipts(receiptsPath)).resolves.toEqual([
      expect.objectContaining({
        outcome: "signed_in",
        quote: expect.objectContaining({
          network: BASE_MAINNET_CAIP2,
          amountAtomic: "0",
        }),
      }),
    ]);
  });

  it("keeps the SIWX proof while continuing through a subsequent payment quote", async () => {
    const directory = await mkdtemp(join(tmpdir(), "vapi-mcp-siwx-pay-"));
    temporaryDirectories.push(directory);
    const fetchImpl = vi
      .fn<typeof fetch>()
      .mockResolvedValueOnce(Response.json(signInRequired(), { status: 402 }))
      .mockResolvedValueOnce(paymentRequired(PAY_TO))
      .mockResolvedValueOnce(Response.json({ paid: true }));

    const result = await callService({
      input: { url: "https://93.184.216.34/weather", method: "GET", maxPriceUsd: "0.01" },
      account: privateKeyToAccount(PRIVATE_KEY),
      config: getDefaultConfig(),
      fetchImpl,
      ledgerPath: join(directory, "ledger.json"),
    });

    expect(result).toMatchObject({
      body: { paid: true },
      payment: { network: BASE_MAINNET_CAIP2, amountAtomic: "2500", payTo: PAY_TO },
    });
    expect(fetchImpl).toHaveBeenCalledTimes(3);
    const paidRequest = fetchImpl.mock.calls[2]![0] as Request;
    expect(paidRequest.headers.has("sign-in-with-x")).toBe(true);
    expect(paidRequest.headers.has("payment-signature")).toBe(true);
  });

  it("dispatches a post-SIWX Solana quote through the real ExactSvmScheme", async () => {
    const directory = await mkdtemp(join(tmpdir(), "vapi-mcp-siwx-svm-pay-"));
    temporaryDirectories.push(directory);
    const account = await createKeystore("test-only-passphrase", join(directory, "keystore.json"), {
      enableSolana: true,
    });
    const config = getDefaultConfig({}, { networks: ["base", "solana"] });
    config.networks[SOLANA_MAINNET_CAIP2]!.rpcUrl = "https://rpc.example";
    let resourceAttempts = 0;
    const fetchImpl = vi.fn<typeof fetch>(async (input, init) => {
      const url = input instanceof Request ? input.url : String(input);
      if (new URL(url).hostname === "rpc.example") {
        const body = init?.body ?? (input instanceof Request ? await input.clone().text() : "");
        const rpc = JSON.parse(String(body)) as { id: string | number; method: string };
        expect(rpc.method).toBe("getAccountInfo");
        return Response.json({
          jsonrpc: "2.0",
          id: rpc.id,
          result: {
            context: { slot: 365_123_456 },
            value: {
              data: [mintAccountBase64(), "base64"],
              executable: false,
              lamports: 1_461_600,
              owner: TOKEN_PROGRAM_ADDRESS,
              rentEpoch: 0,
              space: 82,
            },
          },
        });
      }
      resourceAttempts += 1;
      if (resourceAttempts === 1) return Response.json(signInRequired(), { status: 402 });
      if (resourceAttempts === 2) return solanaPaymentRequired();
      return Response.json({ paid: true });
    });

    const result = await callService({
      input: { url: "https://93.184.216.34/weather", method: "GET", maxPriceUsd: "0.01" },
      account,
      config,
      fetchImpl,
      ledgerPath: join(directory, "ledger.json"),
    });

    expect(result).toMatchObject({
      body: { paid: true },
      payment: {
        network: X402_SOLANA_MAINNET_CAIP2,
        amountAtomic: "2500",
        payTo: "11111111111111111111111111111111",
      },
    });
    expect(resourceAttempts).toBe(3);
    const paidRequest = fetchImpl.mock.calls.find(
      ([input]) =>
        input instanceof Request &&
        input.url === "https://93.184.216.34/weather" &&
        input.headers.has("payment-signature"),
    )?.[0] as Request | undefined;
    expect(paidRequest?.headers.has("sign-in-with-x")).toBe(true);
  });

  it("refuses a SIWX domain mismatch before asking the wallet to sign", async () => {
    const challenge = signInRequired();
    challenge.extensions["sign-in-with-x"].info.domain = "attacker.example";
    const account = privateKeyToAccount(PRIVATE_KEY);
    const signMessage = vi.spyOn(account, "signMessage");
    const fetchImpl = vi
      .fn<typeof fetch>()
      .mockResolvedValueOnce(Response.json(challenge, { status: 402 }));

    await expect(
      callService({
        input: { url: "https://93.184.216.34/weather", method: "GET" },
        account,
        config: getDefaultConfig(),
        fetchImpl,
      }),
    ).rejects.toThrow(/does not match resource host.*Refusing to sign/);
    expect(signMessage).not.toHaveBeenCalled();
    expect(fetchImpl).toHaveBeenCalledOnce();
  });

  it.each([403, 500])(
    "marks a paid HTTP %s without settlement evidence as ambiguous",
    async (status) => {
      const directory = await mkdtemp(join(tmpdir(), "vapi-mcp-marketplace-call-"));
      temporaryDirectories.push(directory);
      const fetchImpl = vi
        .fn<typeof fetch>()
        .mockResolvedValueOnce(Response.json({ services: [service()] }))
        .mockResolvedValueOnce(paymentRequired(PAY_TO))
        .mockResolvedValueOnce(new Response("provider failed", { status }));

      await expect(
        callService({
          input: { id: "imported-weather", maxPriceUsd: "0.01" },
          marketplaceHit: apiHit({ ref: "imported-weather" }),
          account: privateKeyToAccount(PRIVATE_KEY),
          config: getDefaultConfig(),
          fetchImpl,
          lookup: async () => ["93.184.216.34"],
          ledgerPath: join(directory, "ledger.json"),
        }),
      ).rejects.toMatchObject({
        code: "settlement_unknown",
        possibleSettlement: expect.objectContaining({ payTo: PAY_TO, amountAtomic: "2500" }),
      });
      expect(fetchImpl).toHaveBeenCalledTimes(3);
    },
  );

  it("preserves a JSON-compatible custom media type from a browser handoff", async () => {
    const fetchImpl = vi.fn<typeof fetch>().mockResolvedValueOnce(Response.json({ ok: true }));

    await callService({
      input: {
        url: "https://93.184.216.34/weather",
        method: "PATCH",
        body: { city: "Amsterdam" },
        contentType: "application/merge-patch+json",
      },
      account: privateKeyToAccount(PRIVATE_KEY),
      config: getDefaultConfig(),
      fetchImpl,
    });

    expect((fetchImpl.mock.calls[0]![0] as Request).headers.get("content-type")).toBe(
      "application/merge-patch+json",
    );
  });

  it("requires and applies a named endpoint selector for a multi-endpoint API", async () => {
    const multi = service({
      endpoints: [
        endpoint(),
        endpoint({
          name: "forecast",
          method: "GET",
          url: "https://93.184.216.34/forecast",
        }),
      ],
    });
    const ambiguousFetch = vi
      .fn<typeof fetch>()
      .mockResolvedValueOnce(Response.json({ services: [multi] }));
    await expect(
      callService({
        input: { id: "imported-weather" },
        marketplaceHit: apiHit({ ref: "imported-weather" }),
        account: privateKeyToAccount(PRIVATE_KEY),
        config: getDefaultConfig(),
        fetchImpl: ambiguousFetch,
      }),
    ).rejects.toThrow(/endpoint: forecast, weather/);

    const selectedFetch = vi
      .fn<typeof fetch>()
      .mockResolvedValueOnce(Response.json({ services: [multi] }))
      .mockResolvedValueOnce(Response.json({ forecast: true }));
    await callService({
      input: { id: "imported-weather", endpoint: "forecast" },
      marketplaceHit: apiHit({ ref: "imported-weather" }),
      account: privateKeyToAccount(PRIVATE_KEY),
      config: getDefaultConfig(),
      fetchImpl: selectedFetch,
      lookup: async () => ["93.184.216.34"],
    });
    const request = selectedFetch.mock.calls[1]![0] as Request;
    expect(request.url).toBe("https://93.184.216.34/forecast");
    expect(request.method).toBe("GET");
  });

  it("encodes a GET handoff body as query parameters", async () => {
    const fetchImpl = vi.fn<typeof fetch>().mockResolvedValueOnce(Response.json({ weather: true }));

    await callService({
      input: {
        url: "https://93.184.216.34/weather",
        method: "GET",
        body: { city: "Amsterdam", units: "metric" },
      },
      account: privateKeyToAccount(PRIVATE_KEY),
      config: getDefaultConfig(),
      fetchImpl,
    });

    expect((fetchImpl.mock.calls[0]![0] as Request).url).toBe(
      "https://93.184.216.34/weather?city=Amsterdam&units=metric",
    );
  });
});

function apiHit(input: { ref: string; href?: string }) {
  return {
    ref: input.ref,
    kind: "api" as const,
    provenance: "self_listed" as const,
    verification: "none" as const,
    execution: { mode: "direct" as const },
    card: {
      title: "Weather API",
      summary: "Weather through x402.",
      badges: [],
      facts: [],
    },
    action: { type: "invoke_api" as const, href: input.href ?? `/call/${input.ref}` },
  };
}

function endpoint(overrides: Record<string, unknown> = {}) {
  return {
    name: "weather",
    method: "POST",
    url: "https://93.184.216.34/weather",
    price: "$0.0025",
    description: "Current weather.",
    payment: {
      scheme: "exact",
      network: BASE_MAINNET_CAIP2,
      asset: getDefaultConfig().networks[BASE_MAINNET_CAIP2]!.usdc,
      payTo: PAY_TO,
      checkedAt: "2026-08-17T12:00:00.000Z",
    },
    ...overrides,
  };
}

function service(overrides: Record<string, unknown> = {}) {
  return {
    id: "imported-weather",
    name: "Imported weather",
    description: "Current weather.",
    category: "data",
    tier: "listed",
    verified: false,
    wrapped: false,
    price: "$0.0025",
    networks: [BASE_MAINNET_CAIP2],
    endpoints: [endpoint()],
    ...overrides,
  };
}

function paymentRequired(payTo: string, maxTimeoutSeconds = 60) {
  const config = getDefaultConfig();
  return Response.json(
    {
      x402Version: 2,
      resource: { url: "https://93.184.216.34/weather" },
      accepts: [
        {
          scheme: "exact",
          network: BASE_MAINNET_CAIP2,
          amount: "2500",
          asset: config.networks[BASE_MAINNET_CAIP2]!.usdc,
          payTo,
          maxTimeoutSeconds,
          extra: { name: "USD Coin", version: "2" },
        },
      ],
    },
    { status: 402 },
  );
}

async function abortedFetch(input: RequestInfo | URL): Promise<Response> {
  const request = input instanceof Request ? input : new Request(input);
  return await new Promise<Response>((_resolve, reject) => {
    request.signal.addEventListener("abort", () => reject(request.signal.reason), { once: true });
  });
}

function signInRequired() {
  return {
    x402Version: 2,
    accepts: [],
    extensions: {
      "sign-in-with-x": {
        info: {
          domain: "93.184.216.34",
          uri: "https://93.184.216.34/weather",
          statement: "Sign in to view this resource",
          version: "1" as const,
          nonce: "abcdefgh",
          issuedAt: "2026-09-10T08:00:00.000Z",
        },
        supportedChains: [{ chainId: BASE_MAINNET_CAIP2, type: "eip191" as const }],
        schema: { type: "object" },
      },
    },
  };
}

function solanaPaymentRequired() {
  return Response.json(
    {
      x402Version: 2,
      resource: { url: "https://93.184.216.34/weather" },
      accepts: [
        {
          scheme: "exact",
          network: X402_SOLANA_MAINNET_CAIP2,
          amount: "2500",
          asset: SOLANA_MAINNET_USDC,
          payTo: "11111111111111111111111111111111",
          maxTimeoutSeconds: 60,
          extra: {
            feePayer: "SysvarRent111111111111111111111111111111111",
            recentBlockhash: "11111111111111111111111111111111",
            lastValidBlockHeight: "365123999",
            memo: "fixed-vapi-siwx-test",
          },
        },
      ],
    },
    { status: 402 },
  );
}

function mintAccountBase64(): string {
  const data = Buffer.alloc(82);
  data[44] = 6;
  data[45] = 1;
  return data.toString("base64");
}
