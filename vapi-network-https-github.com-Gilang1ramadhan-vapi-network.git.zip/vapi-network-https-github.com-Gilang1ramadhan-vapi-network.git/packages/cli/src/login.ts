import {
  activeAgentMarker,
  createPublicFetch,
  ensureDeviceName,
  formatUsdc,
  getVapiPaths,
  linkRouterAllowanceUsd,
  loadConfig,
} from "@vapi-network/core";
import {
  DEFAULT_AGENT_SCOPES,
  AgentLinkError,
  agentFetch,
  agentSecretAccounts,
  forgetAgentLink,
  pollDeviceLink,
  saveAgentLink,
  startDeviceLink,
  trustedLinkBearer,
  withAgentCredentialLock,
} from "@vapi-network/core/agent-link";

import {
  getEnvironment,
  getSecretStore,
  openInBrowser,
  parseArguments,
  registryBaseUrl,
  targetWallet,
  unlockTarget,
  type CliDependencies,
  type CliIo,
} from "./cli.js";
import { fetchWalletIdentity, formatIdentityLines } from "./identity.js";

const WALLET_OPTION = "--wallet";

export async function loginCommand(
  argv: string[],
  json: boolean,
  io: CliIo,
  dependencies: CliDependencies,
): Promise<void> {
  await runLoginFlow(argv, json, io, dependencies);
}

/** Shared device-link flow used by `vapi login` and `vapi agent create`. */
export async function runLoginFlow(
  argv: string[],
  json: boolean,
  io: CliIo,
  dependencies: CliDependencies,
  options: { routerAllowanceUsd?: number; home?: string; apiBase?: string } = {},
): Promise<void> {
  const parsed = parseArguments(argv, {
    valueOptions: new Set([WALLET_OPTION, "--label"]),
    booleanOptions: new Set(["--publish", "--no-browser"]),
    maximumPositionals: 0,
  });
  const paths = getVapiPaths(options.home);
  const target = await targetWallet(parsed, dependencies, paths.directory);
  const { account } = await unlockTarget(target, dependencies);
  const label = parsed.one("--label") ?? target.name;
  const scopes = [
    ...DEFAULT_AGENT_SCOPES,
    "tasks:read",
    "tasks:write",
    ...(parsed.has("--publish") ? ["call.publish"] : []),
  ];
  const config = await loadConfig(paths.config, process.env, { notice: io.stderr });
  const apiBase = options.apiBase ?? registryBaseUrl(config);
  const fetchImpl = dependencies.fetchImpl ?? createPublicFetch({ allowPrivateNetwork: false });
  const secrets = getSecretStore(dependencies);
  const device = await ensureDeviceName({
    env: getEnvironment(dependencies),
    configPath: paths.config,
    ...(dependencies.hostname === undefined ? {} : { hostname: dependencies.hostname() }),
  });
  const bearer = await trustedLinkBearer({
    store: target.store,
    secrets,
    apiBase,
    exclude: target.name,
    fetchImpl,
    ...(dependencies.now === undefined ? {} : { now: () => dependencies.now!().getTime() }),
  });
  const perDayCapUsd = formatUsdc(BigInt(target.entry.spendCaps.perDayAtomic));
  const routerAllowanceUsd = linkRouterAllowanceUsd({
    scopes,
    explicitUsd: options.routerAllowanceUsd,
    perDayCapUsd,
    trusted: bearer !== undefined,
  });
  const begin = dependencies.agentLink?.startDeviceLink ?? startDeviceLink;
  const poll = dependencies.agentLink?.pollDeviceLink ?? pollDeviceLink;
  const started = await begin({
    apiBase,
    account,
    label,
    scopes,
    fetchImpl,
    device,
    trustDevice: true,
    ...(bearer === undefined ? {} : { bearer }),
    ...(routerAllowanceUsd === undefined ? {} : { routerAllowanceUsd }),
    ...(dependencies.now === undefined ? {} : { now: dependencies.now }),
  });
  if (started.autoApproved) {
    (json ? io.stderr : io.stdout)("Linked on this trusted device.");
  } else {
    const instructions = loginInstructions(
      target.name,
      account.address,
      started.userCode,
      started.verificationUriComplete,
    );
    (json ? io.stderr : io.stdout)(instructions);

    if (
      !parsed.has("--no-browser") &&
      (dependencies.interactive ?? Boolean(process.stdout.isTTY)) &&
      activeAgentMarker(getEnvironment(dependencies)) === undefined
    ) {
      (dependencies.openUrl ?? openInBrowser)(started.verificationUriComplete);
    }
  }

  const result = await poll({
    apiBase,
    start: started,
    fetchImpl,
    ...(started.autoApproved ? { immediate: true } : {}),
  });
  const link = await saveAgentLink({
    secrets,
    wallets: target.store,
    wallet: target.name,
    start: started,
    result,
    apiBase,
    label,
    home: target.store.home,
  });
  const router = result.routerKey !== undefined;

  if (json) {
    io.stdout(
      JSON.stringify({
        wallet: target.name,
        agentWallet: account.address,
        owner: link.owner,
        scopes: link.scopes,
        router,
      }),
    );
    return;
  }

  const routerMessage = router
    ? `Router key stored in ${secrets.description}.`
    : "vAPI Router is not available right now; run vapi router key --rotate later.";
  io.stdout(`Linked ${target.name} to ${shortAddress(link.owner)}. ${routerMessage}`);
}

export async function logoutCommand(
  argv: string[],
  json: boolean,
  io: CliIo,
  dependencies: CliDependencies,
): Promise<void> {
  const parsed = parseArguments(argv, {
    valueOptions: new Set([WALLET_OPTION]),
    maximumPositionals: 0,
  });
  const target = await targetWallet(parsed, dependencies);
  const fetchImpl = dependencies.fetchImpl ?? createPublicFetch({ allowPrivateNetwork: false });
  await forgetAgentLink({
    secrets: getSecretStore(dependencies),
    wallets: target.store,
    wallet: target.name,
    fetchImpl,
    home: target.store.home,
  });
  io.stdout(
    json ? JSON.stringify({ wallet: target.name, unlinked: true }) : `Unlinked ${target.name}.`,
  );
}

export async function whoamiCommand(
  argv: string[],
  json: boolean,
  io: CliIo,
  dependencies: CliDependencies,
): Promise<void> {
  const parsed = parseArguments(argv, {
    valueOptions: new Set([WALLET_OPTION]),
    maximumPositionals: 0,
  });
  const target = await targetWallet(parsed, dependencies);
  const link = target.entry.link;
  if (link === undefined) {
    const identity = await lookupWalletIdentity(target.address, dependencies, io);
    if (json) {
      io.stdout(
        JSON.stringify({
          wallet: target.name,
          ...(target.address === undefined ? {} : { address: target.address }),
          linked: false,
          ...(identity?.ok ? { identity: identity.identity } : {}),
        }),
      );
      return;
    }
    io.stdout(walletHeading(target.name, target.address));
    io.stdout("Not linked. Run vapi login.");
    printIdentity(identity, io);
    return;
  }

  const routerKey = (await getSecretStore(dependencies).has(
    agentSecretAccounts(target.name).routerStake,
  ))
    ? "stored"
    : "missing";
  const status = await agentLinkStatus(target, link, dependencies);
  const identity = await lookupWalletIdentity(target.address, dependencies, io);
  if (json) {
    io.stdout(
      JSON.stringify({
        wallet: target.name,
        ...(target.address === undefined ? {} : { address: target.address }),
        linked: true,
        owner: link.owner,
        label: link.label,
        scopes: link.scopes,
        linkedAt: link.linkedAt,
        routerKey,
        status: status.value,
        ...(identity?.ok ? { identity: identity.identity } : {}),
      }),
    );
    return;
  }

  io.stdout(walletHeading(target.name, target.address));
  io.stdout(
    [
      `Owner: ${link.owner}`,
      `Label: ${link.label}`,
      `Permissions: ${link.scopes.join(" ")}`,
      `Linked: ${link.linkedAt}`,
      `Router key: ${routerKey}`,
      `Status: ${status.line}`,
    ].join("\n"),
  );
  printIdentity(identity, io);
}

async function lookupWalletIdentity(
  address: string | undefined,
  dependencies: CliDependencies,
  io: CliIo,
): Promise<Awaited<ReturnType<typeof fetchWalletIdentity>> | undefined> {
  if (address === undefined) return undefined;
  try {
    const config = await loadConfig(getVapiPaths().config, process.env, { notice: io.stderr });
    return await fetchWalletIdentity({
      baseUrl: registryBaseUrl(config),
      wallet: address,
      ...(dependencies.fetchImpl === undefined ? {} : { fetchImpl: dependencies.fetchImpl }),
    });
  } catch {
    return { ok: false };
  }
}

function printIdentity(
  result: Awaited<ReturnType<typeof fetchWalletIdentity>> | undefined,
  io: CliIo,
): void {
  if (result === undefined || !result.ok) return;
  io.stdout(
    result.identity === null
      ? "On-chain identity: not registered"
      : formatIdentityLines(result.identity).join("\n"),
  );
}

type AgentLinkStatus = {
  value: "active" | "paused" | "revoked" | "unknown";
  line: string;
};

export async function agentLinkStatus(
  target: Awaited<ReturnType<typeof targetWallet>>,
  link: NonNullable<Awaited<ReturnType<typeof targetWallet>>["entry"]["link"]>,
  dependencies: CliDependencies,
): Promise<AgentLinkStatus> {
  const secrets = getSecretStore(dependencies);
  try {
    if (!secrets.available || !(await secrets.has(agentSecretAccounts(target.name).tokens))) {
      return couldNotCheckStatus("no stored agent token");
    }

    const agentFetchArgs = {
      secrets,
      wallets: target.store,
      wallet: target.name,
      ...(dependencies.fetchImpl === undefined ? {} : { fetchImpl: dependencies.fetchImpl }),
      ...(dependencies.now === undefined ? {} : { now: () => dependencies.now!().getTime() }),
    };
    return await withAgentCredentialLock(target.store, `wallet:${target.name}`, async () => {
      await target.store.reload();
      const currentLink = target.store.entry(target.name)?.link;
      if (currentLink === undefined || !sameAgentLink(currentLink, link)) {
        return couldNotCheckStatus("link changed during check");
      }
      const response = await agentFetch(
        agentFetchArgs,
        `${link.apiBase.replace(/\/+$/u, "")}/api/agents/self`,
        { method: "GET" },
      );
      if (response.status === 200) {
        const body = await response
          .clone()
          .json()
          .catch(() => undefined);
        if (
          typeof body === "object" &&
          body !== null &&
          (("status" in body && body.status === "paused") ||
            ("paused" in body && body.paused === true))
        ) {
          return { value: "paused", line: "paused" };
        }
        return { value: "active", line: "active" };
      }
      if (response.status === 401) return revokedStatus();
      if (response.status === 404) {
        return {
          value: "unknown",
          line: "not checked (this console does not support it yet)",
        };
      }
      return couldNotCheckStatus(`HTTP ${response.status}`);
    });
  } catch (error) {
    if (error instanceof AgentLinkError && error.code === "not_linked") {
      return revokedStatus();
    }
    return couldNotCheckStatus(
      error instanceof AgentLinkError && error.code !== "http"
        ? "agent link error"
        : "network error",
    );
  }
}

function revokedStatus(): AgentLinkStatus {
  return {
    value: "revoked",
    line: "revoked or expired on the server. Run vapi login to link again.",
  };
}

function couldNotCheckStatus(reason: string): AgentLinkStatus {
  return { value: "unknown", line: `could not check (${reason})` };
}

function sameAgentLink(
  left: NonNullable<Awaited<ReturnType<typeof targetWallet>>["entry"]["link"]>,
  right: NonNullable<Awaited<ReturnType<typeof targetWallet>>["entry"]["link"]>,
): boolean {
  return (
    left.apiBase === right.apiBase &&
    left.clientId === right.clientId &&
    left.owner === right.owner &&
    left.label === right.label &&
    left.linkedAt === right.linkedAt &&
    left.routerBaseUrl === right.routerBaseUrl &&
    left.scopes.length === right.scopes.length &&
    left.scopes.every((scope, index) => scope === right.scopes[index])
  );
}

function loginInstructions(
  wallet: string,
  address: string,
  userCode: string,
  verificationUrl: string,
): string {
  return [
    "Link this agent to your vAPI account",
    "",
    `  Agent wallet  ${wallet}  ${shortAddress(address)}`,
    `  Code          ${userCode}`,
    `  Open          ${verificationUrl}`,
    "",
    "Sign in there with your own wallet and approve. Waiting…",
  ].join("\n");
}

function walletHeading(name: string, address: string | undefined): string {
  return address === undefined ? `Wallet: ${name}` : `Wallet: ${name} (${address})`;
}

function shortAddress(address: string): string {
  return address.length <= 12 ? address : `${address.slice(0, 6)}…${address.slice(-4)}`;
}
