import js from "@eslint/js";
import tseslint from "typescript-eslint";

export default tseslint.config(
  {
    ignores: [
      "**/coverage/**",
      "**/dist/**",
      "**/node_modules/**",
      "**/publish/**",
      "_import/**",
      // vAPI Desktop build output and the generated shim bundle.
      "apps/desktop/out/**",
      "apps/desktop/release/**",
      "apps/desktop/resources/mcp-shim/**",
    ],
  },
  js.configs.recommended,
  ...tseslint.configs.strict,
  {
    files: ["**/*.ts"],
    rules: {
      "no-undef": "off",
      "no-unused-vars": "off",
      "@typescript-eslint/no-unused-vars": [
        "error",
        { argsIgnorePattern: "^_", caughtErrorsIgnorePattern: "^_" },
      ],
      "@typescript-eslint/no-dynamic-delete": "off",
      "@typescript-eslint/no-non-null-assertion": "off",
      "preserve-caught-error": "off",
    },
  },
  {
    // The MCP server is the surface an agent drives, so it may never reach a
    // recovery phrase, a private key, a vault backup, or the registry key a
    // provider publishes with. See plan 001, "Safety model". There is no
    // publish or backup tool on purpose.
    files: ["packages/mcp/**/*.ts"],
    rules: {
      "no-restricted-imports": [
        "error",
        {
          paths: [
            {
              name: "@vapi-network/core/secrets",
              message:
                "The MCP server must never import a secret-returning function. Secrets stay in the CLI, in front of a person.",
            },
            {
              name: "@vapi-network/core/api-key",
              message:
                "The MCP server must never reach the registry API key. Publishing is a human act, in the CLI.",
            },
            {
              name: "@vapi-network/core/backup",
              message:
                "The MCP server must never reach a vault backup. Backup and restore are human acts, in the CLI and the console.",
            },
            {
              name: "@vapi-network/core/cloud-backup",
              message:
                "The MCP server must never reach a vault backup. Backup and restore are human acts, in the CLI and the console.",
            },
            {
              name: "@vapi-network/core/router-client",
              importNames: ["routerCredentials", "rotateRouterKey"],
              message: "The Router key never reaches MCP.",
            },
          ],
          patterns: [
            {
              group: ["**/core/src/secrets", "**/core/src/secrets.js"],
              message:
                "The MCP server must never import a secret-returning function. Secrets stay in the CLI, in front of a person.",
            },
            {
              group: ["**/core/src/api-key", "**/core/src/api-key.js"],
              message:
                "The MCP server must never reach the registry API key. Publishing is a human act, in the CLI.",
            },
            {
              group: ["**/core/src/backup", "**/core/src/backup.js"],
              message:
                "The MCP server must never reach a vault backup. Backup and restore are human acts, in the CLI and the console.",
            },
            {
              group: ["**/core/src/cloud-backup", "**/core/src/cloud-backup.js"],
              message:
                "The MCP server must never reach a vault backup. Backup and restore are human acts, in the CLI and the console.",
            },
          ],
        },
      ],
    },
  },
  {
    files: ["**/*.mjs"],
    rules: {
      "no-undef": "off",
    },
  },
  {
    files: ["apps/desktop/scripts/**", "apps/desktop/*.cjs"],
    languageOptions: {
      globals: {
        process: "readonly",
        Buffer: "readonly",
        console: "readonly",
        module: "readonly",
        require: "readonly",
        __dirname: "readonly",
        __filename: "readonly",
        URL: "readonly",
        Response: "readonly",
        AbortSignal: "readonly",
      },
    },
    rules: {
      "no-undef": "error",
    },
  },
  {
    files: ["apps/desktop/scripts/**/*.cjs", "apps/desktop/*.cjs"],
    rules: {
      "@typescript-eslint/no-require-imports": "off",
    },
  },
  {
    files: ["apps/desktop/**/*.{ts,tsx}"],
    rules: {
      "@typescript-eslint/no-unused-vars": [
        "error",
        { argsIgnorePattern: "^_", caughtErrorsIgnorePattern: "^_", ignoreRestSiblings: true },
      ],
    },
  },
  {
    files: ["**/*.test.ts"],
    rules: {
      "@typescript-eslint/no-non-null-assertion": "off",
    },
  },
);
